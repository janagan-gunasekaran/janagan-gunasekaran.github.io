#Run createconfigdata.py querying the GTS API/Config DB API ( requests module )
#Run createcloudiso.py ( mkisofs , pyyaml )
#Run movecloudisotovsandatastore.py
#Run mountcloudisotocddrive.ps1 
#Run poweronedgevm.ps1
#Run deployservices ( K3S, Step-CA, Container-Services - ArgoCD, Harbor, Pulp, Metallb, ExternalDNS, local-path StorageClass )
#!/usr/bin/python
import os
import sys
import json
import argparse
import subprocess


sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "Day1"))
import Day1

parser = argparse.ArgumentParser(description="", formatter_class=argparse.RawTextHelpFormatter, epilog=" ")
parser.add_argument("-edgeid", dest="edge_id", help="Input edgeid. Example: -edgeid 1111", type=str)
parser.add_argument("-ztpjson", dest="ztp_json", help="Input path to config.json. Example: -ztpjson /opt/config.json", type=str)
#parser.add_argument('edge_id')
#parser.add_argument('ztp_json')
args = parser.parse_args()

edge_id=args.edge_id
ztp_json=args.ztp_json
#ztp_json="/opt/config.json"
#Jsons will be available in artIfacts folder outside scripts directory

try:
    retcode = subprocess.run(['python3', './Day1/day1.py' ,ztp_json,edge_id])
    if retcode.returncode != 0:
        sys.exit(retcode.returncode)
    else:
        sys.exit(0)
except OSError as e:
    print( e, file=sys.stderr)
    sys.exit(e)

#script exits with exit code 0 if successful else non zero
