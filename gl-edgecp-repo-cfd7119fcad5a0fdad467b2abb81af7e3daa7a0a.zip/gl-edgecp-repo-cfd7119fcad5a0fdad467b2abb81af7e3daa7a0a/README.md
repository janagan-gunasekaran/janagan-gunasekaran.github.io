# gl-edgecp-repo

This repository serves the purpose of deploying and configuring the Edge VM alongside all the essential services required.
In real production scenarios, the code within this repository will be executed from the ZTP (Zero Touch Provisioning) container.

For development purposes, we can follow these steps to deploy the Edge Control Plane:

- Clone this repository onto your system(we have been validating using the Linux environment)
- Ensure to install all the pre-req into the installation system/ZTP container
- Make sure to create a config.json file. A template for config.json is available at gl-edgecp-repo/config.json.
- Run the master_script.py using the command #python3 master-script.py -edgeid 1111 -ztpjson "/opt/config.json".

What does master_script.py do?

The master_script.py script triggers the execution of Day1/day1.py, which in turn operates based on the input from the config.json file. Here are the key actions performed by Day1/day1.py:
- Creation of a cloudinit cidata.iso file to hold specific configuration data.
- Movement of the cidata.iso to the vSAN datastore.
- Mounting of the cidata.iso onto the Edge VM within the ESXi Server.
- Powering on the Edge VM. The Edge VM boots and initiates the cloud-init configurations, taking care of:
-   Data disk partitioning
-   Network configurations
-   Chronyd/timezone configurations
-   Filebeat configurations
-   DNS configurations
- Step-ca configurations.
- Deployment of K3S with the Flannel backend.
- PSA (Pod Security Admission) configurations.
- Deployment of ExternalDNS.
- Deployment of StorageClass.
- Deployment of MetalLB (Load Balancer).
- Harbor deployments and configurations.
- Harbor Image Pruning.
- Harbor Replications with the Data Center (DC).
- ArgoCD deployments.
- Multus deployments.
- Pulp deployments.

During any of these deployment or configuration steps, the script either exits with a non-zero exit code in case of an error or continues to the next deployment upon success. This ensures that the process remains robust and responsive to different scenarios.

