import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
import base64
from commonutils import SSHPython
PURPOSE = "Deploy Argocd"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-harborpassword", dest="harborpassword", help="Input harborpassword: -harborpassword password123", type=str, default="none")
    parser.add_argument("-argocdpassword", dest="argocdpassword", help="Input argocdpassword: -argocdpassword password123", type=str, default="none")
    parser.add_argument("-domain", dest="domain", help="Input domain: -domain cgw-hpe.net", type=str, default="none")
    parser.add_argument("-squidIP", dest="squidIP", help="Input squidIP: -squidIP 172.30.0.20", type=str, default="none")
    parser.add_argument("-env", dest="env", help="Input env: -env integ", type=str, default="none")
    parser.add_argument("-mode", dest="mode", help="Input mode: -mode install", type=str, default="none")
    parser.add_argument("-type", dest="type", help="Input type: -type singlenode", type=str, default="none")
    parser.add_argument("-dcdomainname", dest="dcdomainname", help="Input dcdomain: -dcdomainname cgw-hpe.net", type=str, default="none")
    parser.add_argument("-storeID", dest="storeID", help="Input store ID: -storeID 'ST0000'", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password

    argocdpassword = args.argocdpassword
    password_bytes = argocdpassword.encode("ascii")
    base64_bytes = base64.b64encode(password_bytes)
    en_argocdpassword = base64_bytes.decode("ascii")

    harborpassword = args.harborpassword
    password_bytes = harborpassword.encode("ascii")
    base64_bytes = base64.b64encode(password_bytes)
    en_harborpassword = base64_bytes.decode("ascii")

    cmd = "python3 /opt/gateway/automation/container-services/argocd/deployArgocd.py -domain {0} -squidIP {1} -argocdPassword '{2}' -harborPassword '{3}' -mode {4} -type {5} -env {6} -dcdomainname {7} -storeID {8}".format(args.domain, args.squidIP, en_argocdpassword, en_harborpassword, args.mode, args.type, args.env, args.dcdomainname, args.storeID)
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_argocdpassword, en_harborpassword], exitCode=True)
        if "ArgoCD Deployed successfully" in output:
            ExitCode = 0
            print("ArgoCD deployed successfully")
        else:
            ExitCode = 1
            print("Failed to Deploy ArgoCD with Custom CSR Certificate")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1


    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
