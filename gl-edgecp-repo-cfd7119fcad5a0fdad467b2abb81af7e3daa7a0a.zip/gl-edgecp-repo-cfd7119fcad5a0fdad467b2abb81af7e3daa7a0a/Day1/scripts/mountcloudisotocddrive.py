import ssl
import time
from pyVim import connect
from pyVmomi import vim
import argparse
from argparse import RawTextHelpFormatter
import sys
PURPOSE = "Mount cloud ISO to cd drive and power on vm"

def connect_to_esxi(host, user, password, httpProxyHost, port=443,disable_ssl_validation=True):
    # Disable SSL certificate verification if needed
    if disable_ssl_validation:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS)
        context.verify_mode = ssl.CERT_NONE
    else:
        context = None

    # Connect to the ESXi server
    service_instance = connect.SmartConnect(
        host=host,
        user=user,
        pwd=password,
        port=port,
        sslContext=context,
        httpProxyHost=httpProxyHost,
        httpProxyPort=3128
    )
    if not service_instance:
       service_instance = connect.SmartConnect(
        host=host,
        user=user,
        pwd=password,
        port=port,
        sslContext=context
    ) 

    return service_instance

def power_off_vm(vm):
    if vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOn:
        task = vm.PowerOffVM_Task()
        wait_for_task(task)
        print("VM is Powered OFF")

def power_on_vm(vm):
    if vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOff:
        task = vm.PowerOnVM_Task()
        wait_for_task(task)
        print("VM is Powered ON")

def mount_iso(service_instance, vm_name, datastore_name, iso_path):
    content = service_instance.RetrieveContent()
    vm = get_vm_by_name(content, vm_name)
    if not vm:
        print(f"Virtual machine '{vm_name}' not found.")
        return False
    print(f"Virtual machine '{vm_name}' found.")
    # Power off the VM if it's powered on
    power_off_vm(vm)

    datastore = get_datastore_by_name(content, datastore_name)
    if not datastore:
        print(f"Datastore '{datastore_name}' not found.")
        return False
    print(f"Datastore '{datastore_name}' found.")
    # Attach the CD-ROM drive and mount the ISO
    vm_mount_spec = vim.vm.ConfigSpec()
    cdrom_spec = vim.vm.device.VirtualDeviceSpec()
    cdrom_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
    cdrom_spec.device = get_cdrom_device(vm)
    cdrom_spec.device.backing = vim.vm.device.VirtualCdrom.IsoBackingInfo()
    cdrom_spec.device.backing.fileName = iso_path
    cdrom_spec.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
    cdrom_spec.device.connectable.connected = True
    cdrom_spec.device.connectable.startConnected = True

    vm_mount_spec.deviceChange = [cdrom_spec]
    task = vm.ReconfigVM_Task(vm_mount_spec)

    # Wait for the task to complete
    print(f"task is '{task}'")
    print(task.info.state)
    wait_for_task(task)

    time.sleep(10)
    power_on_vm(vm)
    print("---------")
    print(vm.runtime.powerState)
    print("---------")

    # Power on the VM
    while vm.runtime.powerState != vim.VirtualMachinePowerState.poweredOn:
        print("In power on loop")
        print(vm.runtime.powerState)
        power_on_vm(vm)
        time.sleep(5)  

    # Disconnect from the ESXi server (this should be done after the operation)
    connect.Disconnect(service_instance)
    return True

def wait_for_task(task):
    """Waits and returns the result of the given task."""
    print(f"Waiting for task inside wait_for_task '{task}'")
    print(task.info.state)
    while task.info.state == vim.TaskInfo.State.running:
        print(task.info.state)
        time.sleep(1)
    return task.info.state

def get_vm_by_name(content, vm_name):
    vm_view = content.viewManager.CreateContainerView(
        content.rootFolder,
        [vim.VirtualMachine],
        True
    )
    for vm in vm_view.view:
        if vm.name == vm_name:
            return vm
    return None

def get_datastore_by_name(content, datastore_name):
    datastores = content.viewManager.CreateContainerView(
        content.rootFolder,
        [vim.Datastore],
        True
    )
    for ds in datastores.view:
        if ds.name == datastore_name:
            return ds
    return None

def get_cdrom_device(vm):
    for device in vm.config.hardware.device:
        if isinstance(device, vim.vm.device.VirtualCdrom):
            return device
    return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-datastore_name", dest="datastore_name", help="Input datastore name: -datastore_name datastore1", type=str, default="none")
    parser.add_argument("-vm_name", dest="vm_name", help="Input vm_name: -vm_name xyz", type=str, default="none")
    parser.add_argument("-iso_name", dest="iso_name", help="Input iso name: -iso_name cidata.iso", type=str, default="none")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-httpProxyHost", dest="httpProxyHost", help="Input httpProxyHost IP: -httpProxyHost 172.30.0.20", type=str, default="none")

    args = parser.parse_args()
    esxi_host = args.host
    esxi_user = args.username
    esxi_password = args.password
    vm_name = args.vm_name
    datastore_name = args.datastore_name
    iso_name = args.iso_name
    httpProxyHost = args.httpProxyHost
    
    iso_path = f"[{datastore_name}] {vm_name}/{iso_name}"

    ExitCode = 0
    service_instance = connect_to_esxi(esxi_host, esxi_user, esxi_password,httpProxyHost=httpProxyHost)
    if service_instance:
        status = mount_iso(service_instance, vm_name, datastore_name, iso_path)
        if status:
            ExitCode = 0
            print("Mounted ISO on to vm and powered on vm successfully")
        else:
            ExitCode = 1
            print("Mounted ISO on to vm and powered on vm successfully")
    else:
        ExitCode = 1
        print("Failed to connect to host ",esxi_host)

    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)