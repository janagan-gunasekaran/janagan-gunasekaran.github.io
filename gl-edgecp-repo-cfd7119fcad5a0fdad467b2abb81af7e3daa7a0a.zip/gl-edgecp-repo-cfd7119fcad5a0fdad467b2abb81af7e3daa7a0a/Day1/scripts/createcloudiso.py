import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
import shutil

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "mod_cloudinit"))
PURPOSE = "Create cloud iso"
ExitCode = 0
def execute_command(cmd):
        process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, universal_newlines=True)
        out, err = process.communicate()
        print("Executing command %s and output,status_code is %s-%s"%(cmd, out, process.returncode))
        return (process.returncode, out,err)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-configfilepath", dest="configfilepath", help="Input config file: -configfilepath ./edge_config.json", type=str, default="none")
    parser.add_argument("-cloudtemplates", dest="cloudtemplates", help="Input cloudtemplates filepath: -cloudtemplates ./edge_templates/", type=str, default="none")
    parser.add_argument("-cloudconfigdest", dest="cloudconfigdest", help="Input cloudconfigdest filepath: -cloudconfigdest ./output/", type=str, default="none")
    args = parser.parse_args()
    configfilepath =args.configfilepath
    cloudtemplates =args.cloudtemplates
    cloudconfigdest =args.cloudconfigdest

    #Supports parallel store bringup
    #os.makedirs(cloudconfigdest, exist_ok=True)
    filetocopy = "clusteradm_linux_amd64.tar.gz"
    sourcepath = '/'.join(cloudconfigdest.rstrip('/').split('/')[:-1])
    source = f"{sourcepath}/{filetocopy}"
    dest = f"{cloudconfigdest}{filetocopy}"
    shutil.copy2(source , dest)
    
    wrapper_script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils","wrapper_cloudinit.py")
    cmd = "python3 {0} -v {1} -t {2} -o {3}".format(wrapper_script_path, configfilepath,cloudtemplates,cloudconfigdest)
    status, cmd_out, cmd_err = execute_command(cmd)
    if status == 0:
        print("Successfully created cloud-init files from templates provided")
        mkiso_cmd = "mkisofs -iso-level 4 --allow-lowercase --allow-multidot -V cidata -o {0}cidata.iso {1}".format(cloudconfigdest,cloudconfigdest)
        status, cmd_out, cmd_err = execute_command(mkiso_cmd)
        if status == 0:
            print("Successfully created iso file")
            ExitCode = 0
        else:
            print("Failed to create iso file")
            ExitCode = 1
    else:
        print("Failed to create cloud-init files from templates provided")
        ExitCode = 1
    
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)