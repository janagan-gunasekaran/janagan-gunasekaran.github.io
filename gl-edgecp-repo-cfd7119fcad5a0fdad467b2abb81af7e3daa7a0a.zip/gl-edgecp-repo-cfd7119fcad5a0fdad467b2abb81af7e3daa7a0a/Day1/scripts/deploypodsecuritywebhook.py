import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))

from commonutils import SSHPython
PURPOSE = "Deploy Pod Security Webhook"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password

    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","commonutils")
        scp = client.open_sftp()
        scp.put(f'{filepath}/k3s_psa/deploy_podsecuritywebhook.py', '/opt/gateway/scripts/deploy_podsecuritywebhook.py')
        scp.close()
        print("Copy PSA script to edge vm, Pass")

        cmd = "python3 /opt/gateway/scripts/deploy_podsecuritywebhook.py"
        status, output, error = SSHPython.execute_command(client, cmd, timeout=1800, exitCode=True)
        if status:
            ExitCode = 0
            print("Pod Security Webhook deployed successfully")
        else:
            ExitCode = 1
            print("Failed to Deploy od Security Webhook")

    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
