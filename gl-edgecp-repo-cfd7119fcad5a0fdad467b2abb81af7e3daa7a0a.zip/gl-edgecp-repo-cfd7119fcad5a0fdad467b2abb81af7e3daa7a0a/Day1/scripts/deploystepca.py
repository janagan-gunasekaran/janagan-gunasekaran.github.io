import argparse
from argparse import RawTextHelpFormatter
import os
import sys
import base64
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
from commonutils import SSHPython

PURPOSE = "Deploy Step-ca"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, required=True)
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, required=True)
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, required=True)
    parser.add_argument("-dnsserver", dest="dnsserver", help="Input dns server ip", type=str, required=True)
    parser.add_argument("-dnsdomain", dest="dnsdomain", help="Input dns domain name", type=str, required=True)
    parser.add_argument("-coreserver", dest="coreserver", help="Input core server", type=str, required=True)
    parser.add_argument("-corefingerprint", dest="corefingerprint", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-rootcert", dest="rootcert", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-rootkey", dest="rootkey", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-intermediatecert", dest="intermediatecert", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-intermediatekey", dest="intermediatekey", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-pdnsapikey", dest="pdnsapikey", help="Input pdns api key", type=str, required=True)

    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password

    root_cert_encoded = args.rootcert
    rootcert_base64_bytes = root_cert_encoded.encode("ascii")
    cert_bytes = base64.b64decode(rootcert_base64_bytes)
    root_cert = cert_bytes.decode("ascii")
    root_key_encoded = args.rootkey
    rootkey_base64_bytes = root_key_encoded.encode("ascii")
    key_bytes = base64.b64decode(rootkey_base64_bytes)
    root_key = key_bytes.decode("ascii")
    intermediate_cert_encoded = args.intermediatecert
    intermediatecert_base64_bytes = intermediate_cert_encoded.encode("ascii")
    cert_bytes = base64.b64decode(intermediatecert_base64_bytes)
    intermediate_cert = cert_bytes.decode("ascii")
    intermediate_key_encoded = args.intermediatekey
    intermediatekey_base64_bytes = intermediate_key_encoded.encode("ascii")
    key_bytes = base64.b64decode(intermediatekey_base64_bytes)
    intermediate_key = key_bytes.decode("ascii")
    corefingerprint_encoded = args.corefingerprint
    corefingerprint_base64_bytes = corefingerprint_encoded.encode("ascii")
    corefingerprint_bytes = base64.b64decode(corefingerprint_base64_bytes)
    corefingerprint_dec = corefingerprint_bytes.decode("ascii").strip()
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","commonutils")
        scp = client.open_sftp()
        scp.put(f'{filepath}/stepcafiles/GenerateCertificate.py', '/opt/gateway/scripts/GenerateCertificate.py')
        scp.put(f'{filepath}/stepcafiles/certvm.json', '/opt/gateway/conf/certvm.json')
        cmd01 = 'mkdir -p /opt/glcg/certificates/certs && mkdir -p /opt/glcg/certificates/secrets'
        status01, output01, error01 = SSHPython.execute_command(client, cmd01, exitCode=True)
        if status01 == 'Fail':
            print(f'Unable to execute command {cmd01}')
            sys.exit(1)
        #copy root and intermediate certificates
        with scp.file('/opt/glcg/certificates/certs/root_ca.crt', 'w') as root_cert_file:
            root_cert_file.write(root_cert)
        with scp.file('/opt/glcg/certificates/certs/intermediate_ca.crt', 'w') as intermediate_cert_file:
            intermediate_cert_file.write(intermediate_cert)
        with scp.file('/opt/glcg/certificates/secrets/root_ca_key', 'w') as root_key_file:
            root_key_file.write(root_key)
        with scp.file('/opt/glcg/certificates/secrets/intermediate_ca_key', 'w') as intermediate_key_file:
            intermediate_key_file.write(intermediate_key)
        scp.close()

        #Copy certificates to k3s
        copy_certs_commands = [
            'mkdir -p /var/lib/rancher/k3s/server/tls/etcd',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /var/lib/rancher/k3s/server/tls/server-ca.crt',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /var/lib/rancher/k3s/server/tls/client-ca.crt',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /var/lib/rancher/k3s/server/tls/request-header-ca.crtm',
            'cp /opt/glcg/certificates/secrets/intermediate_ca_key /var/lib/rancher/k3s/server/tls/server-ca.key',
            'cp /opt/glcg/certificates/secrets/intermediate_ca_key /var/lib/rancher/k3s/server/tls/client-ca.key',
            'cp /opt/glcg/certificates/secrets/intermediate_ca_key /var/lib/rancher/k3s/server/tls/request-header-ca.key',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /var/lib/rancher/k3s/server/tls/etcd/server-ca.crt',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /var/lib/rancher/k3s/server/tls/etcd/peer-ca.crt',
            'cp /opt/glcg/certificates/secrets/intermediate_ca_key /var/lib/rancher/k3s/server/tls/etcd/server-ca.key',
            'cp /opt/glcg/certificates/secrets/intermediate_ca_key /var/lib/rancher/k3s/server/tls/etcd/peer-ca.key',
            'cp /opt/glcg/certificates/certs/intermediate_ca.crt /etc/ssl/certs/CA.pem'
        ]
        for cmd in copy_certs_commands:
            status, output, error = SSHPython.execute_command(client, cmd, exitCode=True)
            if status == 'Fail':
                ExitCode = 1
                print(f'Failed to execute command - {cmd}, ERROR: {error}')
                break
        else:
            cmd02 = "python3 /opt/gateway/scripts/GenerateCertificate.py -dnsserver {0} -dnsdomain {1} -coreserver {2} -corefingerprint {3} -pdnsapikey {4}".format(args.dnsserver, args.dnsdomain, args.coreserver, corefingerprint_dec, args.pdnsapikey)
            status02, output02, error02 = SSHPython.execute_command(client, cmd02, timeout=1800, exitCode=True)
            if "GenerateCertificate : Passed" in output02:
                ExitCode = 0
                print("Step-ca deployed successfully")
            else:
                ExitCode = 1
                print("Failed to Deploy step-ca")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
