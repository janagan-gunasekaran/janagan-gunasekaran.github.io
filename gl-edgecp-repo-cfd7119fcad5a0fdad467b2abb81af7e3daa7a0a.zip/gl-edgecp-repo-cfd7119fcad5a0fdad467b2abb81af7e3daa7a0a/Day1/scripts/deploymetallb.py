import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))

from commonutils import SSHPython
PURPOSE = "Deploy Metallb"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-startIp", dest="startIp", help="Input startIp: -startIp 172.28.6.84", type=str, default="none")
    parser.add_argument("-endIp", dest="endIp", help="Input endIp: -dcpdns_hostip 172.30.0.110", type=str, default="none")
    parser.add_argument("-mode", dest="mode", help="Input mode: -mode install", type=str, default="none")
    parser.add_argument("-type", dest="type", help="Input type: -type edge", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password
    cmd = "python3 /opt/gateway/automation/container-services/metallb/deployMetalLB.py -startIp {0} -endIp {1} -mode {2} -type {3}".format(args.startIp, args.endIp, args.mode, args.type)
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        status, cmd_out, cmd_err = SSHPython.execute_command(client, cmd)
        if "MetalLB Deployed Successfully" in cmd_out:
            print("Successfully deployed MetalLB")
            ExitCode = 0
        else:
            ExitCode = 1
            print("failed to deploy MetalLB")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1

    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()