import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))

from commonutils import SSHPython
PURPOSE = "Deploy External DNS"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-domain", dest="domain", help="Input domain: -domain cgw-hpe.net", type=str, default="none")
    parser.add_argument("-dcdomain", dest="dcdomain", help="Input dcdomain: -dcdomain cgw-hpe.net", type=str, default="none")
    parser.add_argument("-pdns_hostip", dest="pdns_hostip", help="Input pdns_hostip: -pdns_hostip 172.28.6.83", type=str, default="none")
    parser.add_argument("-pdns_apiKey", dest="pdns_apiKey", help="Input pdns_apiKey: -pdns_hostip pdns", type=str, default="none")
    parser.add_argument("-dcpdns_hostip", dest="dcpdns_hostip", help="Input dcpdns_hostip: -dcpdns_hostip 172.30.0.110", type=str, default="none")
    parser.add_argument("-dcpdns_apiKey", dest="dcpdns_apiKey", help="Input dcpdns_apiKey: -dcpdns_apiKey pdns", type=str, default="none")
    parser.add_argument("-mode", dest="mode", help="Input mode: -mode install", type=str, default="none")
    parser.add_argument("-type", dest="type", help="Input type: -type edge", type=str, default="none")
    parser.add_argument("-PTRDOMAINLINES", dest="PTRDOMAINLINES", help="Input PTRDOMAINLINES: -PTRDOMAINLINES 6.28.172.in-addr.arpa", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password
    cmd1 = "pip3 install ruamel.yaml==0.17.35"
    cmd = "python3 /opt/gateway/automation/container-services/externaldns/deployExternalDNS.py -domain {0} -pdns_hostip {1} -pdns_apiKey {2} -dcpdns_hostip {3} -dcpdns_apiKey {4} -mode {5} -type {6} -PTRDOMAINLINES {7}".format(args.domain, args.pdns_hostip, args.pdns_apiKey, args.dcpdns_hostip, args.dcpdns_apiKey, args.mode, args.type, args.PTRDOMAINLINES)
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        status, cmd_out, cmd_err = SSHPython.execute_command(client, cmd1)
        if "Requirement already satisfied" or "Successfully installed ruamel.yaml-0.17.35" in cmd_out:
            print("Installed ruamel.yaml")
            ExitCode = 0
        else:
            print("Pre-req ruamel.yaml is not installed. Terminating the flow")
            ExitCode = 1
            sys.exit(1)
        status, cmd_out, cmd_err = SSHPython.execute_command(client, cmd)
        if "ExternalDNS Deployed Successfully" in cmd_out:
            ExitCode = 0
            print("Successfully deployed External DNS ....")
        else:
            print("Failed to configure External DNS")
            ExitCode = 1
    else:
        print("SSH to edge vm failed")
        ExitCode = 1
    
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()