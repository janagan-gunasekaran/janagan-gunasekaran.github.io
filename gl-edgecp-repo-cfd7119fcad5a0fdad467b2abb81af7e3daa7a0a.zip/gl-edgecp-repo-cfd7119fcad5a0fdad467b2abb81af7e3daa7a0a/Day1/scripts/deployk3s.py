import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
import time
import paramiko
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
from commonutils import SSHPython

PURPOSE = "Deploy K3S"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-csversionoct", dest="csversionoct", help="Input container service version oct", type=str, default="none")
    parser.add_argument("-csversionmar", dest="csversionmar", help="Input container service version mar", type=str, default="none")
    parser.add_argument("-rpmchecksumoct", dest="rpmchecksumoct", help="Enter the sha256checksum of lhcp container services rpm. Input rpmchecksum: -rpmchecksum e031e59769c40df31c69c40372cc66e8938cdd83e1dc05cabc0087190daf461d", type=str, default="none")
    parser.add_argument("-rpmchecksummar", dest="rpmchecksummar", help="Enter the sha256checksum of lhcp container services rpm. Input rpmchecksum: -rpmchecksum e031e59769c40df31c69c40372cc66e8938cdd83e1dc05cabc0087190daf461d", type=str, default="none")
    parser.add_argument("-psaversion", dest="psaversion", help="Input pod security webhook version: -psaversion psaversion", type=str, default="none")
    parser.add_argument("-psaimageversion", dest="psaimageversion", help="Input pod security webhook docker image version: -psaimageversion psaimageversion", type=str, default="none")
    parser.add_argument("-jfroguser", dest="jfroguser", help="Input jfroguser: -jfroguser jfroguser", type=str, default="none")
    parser.add_argument("-jfrogpassword", dest="jfrogpassword", help="Input jfrogpassword: -jfrogpassword jfrogpassword", type=str, default="none")
    parser.add_argument("-psacontimg", dest="psacontimg", help="Enter the sha256checksum of psa container image. Input psacontimg: -psacontimg 1cef343a059e2e87b4321c2bb1d5c434988c4903e9835f6c0e7f9a3de76e37e8", type=str, default="none")
    parser.add_argument("-psatgzchecksum", dest="psatgzchecksum", help="Enter the sha256checksum of psa tgz. Input psatgzchecksum: -psatgzchecksum 6a192b401e40b74eb1bb44a6e04f7ddfcf678201950d9859a89bcd0065bd0fdc", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password
    csversionoct = args.csversionoct
    csversionmar = args.csversionmar
    rpmchecksumoct = args.rpmchecksumoct
    rpmchecksummar = args.rpmchecksummar
    psaversion = args.psaversion
    psaimageversion = args.psaimageversion
    jfroguser = args.jfroguser
    jfrogpassword = args.jfrogpassword
    psacontimg = args.psacontimg
    psatgzchecksum = args.psatgzchecksum 
    csversion = 0
    rpmchecksum = 0

 
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","commonutils")
        scp = client.open_sftp()
        scp.put(f'{filepath}/k3s_psa/deploy_k3s.py', '/opt/gateway/scripts/deploy_k3s.py')
        scp.close()
        print("Copy k3s script to edge vm, Pass")

        cmd = "cat /etc/lhcp/release"
        print("Executing below command on edge vm :")
        status, output, error = SSHPython.execute_command(client, cmd, timeout=1800, exitCode=True)
        if "2.0.20231012" in output:
            csversion = csversionoct
            rpmchecksum = rpmchecksumoct
        elif "2.0.20240331" in output:
            csversion = csversionmar
            rpmchecksum = rpmchecksummar            
        print("Value of csversion is ------" , csversion)
        print("Value of rpmchecksum is -----" , rpmchecksum)
        cmd = f"python3 /opt/gateway/scripts/deploy_k3s.py -csversion {csversion} -rpmchecksum '{rpmchecksum}' -psaversion {psaversion} -psaimageversion {psaimageversion} -jfroguser {jfroguser} -jfrogpassword '{jfrogpassword}' -psacontimg '{psacontimg}' -psatgzchecksum '{psatgzchecksum}'"
        status, output, error = SSHPython.execute_command(client, cmd, timeout=1800, exitCode=True)
        
        if "K3S deployed successfully" in output+error:
            ExitCode = 0
            print("K3S deployed successfully")
        else:
            ExitCode = 1
            print("Failed to Deploy K3S")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()