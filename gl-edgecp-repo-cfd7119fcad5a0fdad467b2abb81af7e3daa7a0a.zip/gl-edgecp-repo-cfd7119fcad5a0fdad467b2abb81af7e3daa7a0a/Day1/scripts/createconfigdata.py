import requests
import yaml

def make_rest_api_call(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def create_yaml_file(data, file_path):
    with open(file_path, 'w') as file:
        yaml.dump(data, file, default_flow_style=False)

# Example API call
api_url = "https://api.example.com/data"
response_data = make_rest_api_call(api_url)

if response_data:
    # Example file path to store the YAML data
    yaml_file_path = "response_data.yaml"

    # Create YAML file from response data
    create_yaml_file(response_data, yaml_file_path)
    print(f"YAML file '{yaml_file_path}' created successfully.")
else:
    print("API call failed or response is empty.")