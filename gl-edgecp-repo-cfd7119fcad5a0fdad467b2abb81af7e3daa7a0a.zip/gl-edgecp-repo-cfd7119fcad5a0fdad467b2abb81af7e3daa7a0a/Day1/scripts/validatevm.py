import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
PURPOSE = "Validate VM"
import ruamel.yaml
import logging
import time
from commonutils import SSHPython

def validateDNSwithnslookup(client,hostname):
    forwardlookupcmd = f"nslookup {hostname}"
    status,output,error = SSHPython.execute_command(client, forwardlookupcmd, exitCode=True)

    if hostname.strip() in output and "SERVFAIL" not in output and "** server can't find" not in output:
        print(f"nslookup {hostname} successful ")
    else:
        print(f"nslookup {hostname} FAILED, Check DNS Configurations Manually")
    externalSvrlookupcmd = f"nslookup google.com"
    status1,output,error = SSHPython.execute_command(client, externalSvrlookupcmd, exitCode=True)

    if "connection timed out" in output:
        print("nslookup of external servers failed. Check DNS Configurations Manually")
    else:
        print("nslookup of external servers successful")
    if status == 'Pass' and status1 == 'Pass':
        return True
    else:
        return False

def validate_ntp(client, scid_ntp):
    print("\nValidating NTP:")
    #print(scid_ntp)
    for i in range(0,6):
        result_flag, ssh_output1, ssh_error = SSHPython.execute_command(client,"timedatectl | grep synchronized | cut -d ':' -f 2")
        if "yes" in ssh_output1:
            break
        else:
            time.sleep(30)
    if "yes" in ssh_output1:
        print("System clock synchronized")
        description = "System clock synchronized"
        res = "Pass"
        result_flag, ssh_output2, ssh_error = SSHPython.execute_command(client,"chronyc sources | awk '/\^\*/{print $2}'")
        if ssh_output2.strip() in scid_ntp:
            description = "System clock synchronized and Active NTP IP is as per scid"
            res = "Pass"
        else:
            description = "System clock synchronized and Active NTP IP is not as per scid"
            res = "Fail"  
    else:
        description = "NTP is not in sync"
        res = "Fail"
    return res, description

def ping_ip(ip_address):
    try:
        subprocess.check_output(['nc', '-zv', ip_address, '22'])
        return True
    except subprocess.CalledProcessError:
        return False

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    #parser.add_argument("-fpath", dest="fpath", help="Input config file: -fpath ./edge_config.json", type=str, default="none")
    parser.add_argument("-ntpserver1", dest="ntpserver1", help="Input ntpserver1: -ntpserver1 172.28.0.1", type=str, default="none")
    parser.add_argument("-ntpserver2", dest="ntpserver2", help="Input ntpserver3: -ntpserver2 172.28.0.2", type=str, default="none")
    parser.add_argument("-ntpserver3", dest="ntpserver3", help="Input ntpserver3: -ntpserver3 172.28.0.3", type=str, default="none")
    parser.add_argument("-vmname", dest="vmname", help="Input vmname: -vmname edge01", type=str, default="none")
    parser.add_argument("-edgeuser", dest="edgeuser", help="Input edgeuser: -edgeuser root", type=str, default="none")
    parser.add_argument("-edgepassword", dest="edgepassword", help="Input edgepassword: -edgepassword Password!234", type=str, default="none")
    parser.add_argument("-vmip", dest="vmip", help="Input vmip: -vmip 172.28.6.90", type=str, default="none")
    args = parser.parse_args()
    ExitCode = 0
    ExitCode_list = []
    edgepassword = args.edgepassword
    edgeuser = args.edgeuser
    ntpserver1 = args.ntpserver1
    ntpserver2 = args.ntpserver2
    ntpserver3 = args.ntpserver3
    vmname = args.vmname
    vmip = args.vmip
    #if flag: 
    #checking if vmip is reachable
    flag2 = False
    timeout = time.time() + 60*10
    while time.time() < timeout:
        ret = ping_ip(vmip)
        if ret:
            flag2 = True
            print(f"{vmip} is reachable")
            break
    if flag2:
        t = 0
        while t<=1200:
            time.sleep(30)
            client, resultFlag = SSHPython.establish_ssh_connection(vmip,edgeuser,edgepassword)
            cmd01 = "[ -f /root/rebootdone ] && echo 'File exists' || echo 'File does not exists'"
            status01, output01, error01 = SSHPython.execute_command(client,cmd01)
            t += 30
            if status01 == "Pass" and "File exists" in output01 and resultFlag == "Pass":
                print("-------------------------------")
                #validate ntp
                time.sleep(15)
                ntp_list = [ntpserver1, ntpserver2, ntpserver3]
                res, description = validate_ntp(client, ntp_list)
                if res == "Pass":
                    print(description)
                    print("Validating NTP: Passed")
                    
                else:
                    print(description)
                    print("Validating NTP: Failed")
                    ExitCode_list.append(1) 
                print("-------------------------------")
                #validate nslookup for vm hostname and google.com    
                res = validateDNSwithnslookup(client,vmname)
                if not res:
                    ExitCode_list.append(1) 
                    print("Validating DNS: failed")
                else:
                    print("Validating DNS: Passed") 
                print("-------------------------------")
                #validating filebeat
                cmd3 = "systemctl is-enabled filebeat"
                result_flag, ssh_output3, ssh_error = SSHPython.execute_command(client,cmd3)
                if "enabled" in ssh_output3:
                    print("Filebeat is enabled")
                else:
                    print("Filebeat is not enabled")
                    ExitCode_list.append(1)
                break
            elif resultFlag == "Pass" and 'File does not exists' in output01:
                print("/root/rebootdone file not found")
        else:
            print("Error: Timeout in vm validation")
            ExitCode_list.append(1)
                
    else:
        print(f"{vmip} is unreachable, please check manually!")
        ExitCode_list.append(1)

    if 1 in ExitCode_list:
        ExitCode = 1
    
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)
    

if __name__ == "__main__":
    main()
