import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
import base64
from commonutils import SSHPython
PURPOSE = "Deploy harbor"

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-harborpassword", dest="harborpassword", help="Input harborpassword: -harborpassword password123", type=str, default="none")
    parser.add_argument("-domain", dest="domain", help="Input domain: -domain cgw-hpe.net", type=str, default="none")
    parser.add_argument("-dcdomain", dest="dcdomain", help="Input dcdomain: -domain cgw-hpe.net", type=str, default="none")
    parser.add_argument("-squidIP", dest="squidIP", help="Input squidIP: -squidIP 172.30.0.20", type=str, default="none")
    parser.add_argument("-nodes", dest="nodes", help="Input nodes: -nodes /opt/gateway/automation/container-services/conf/nodes.json", type=str, default="none")
    parser.add_argument("-mode", dest="mode", help="Input mode: -mode install", type=str, default="none")
    parser.add_argument("-type", dest="type", help="Input type: -type singlenode", type=str, default="none")
    parser.add_argument("-nginxip", dest="nginxip", help="Input nginxip: ", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password

    harborpassword = args.harborpassword
    password_bytes = harborpassword.encode("ascii")
    base64_bytes = base64.b64encode(password_bytes)
    en_harborpassword = base64_bytes.decode("ascii")

    cmd = "python3 /opt/gateway/automation/container-services/harbor/deployHarbor.py  -domain {0} -dcdomain {1} -harborPassword '{2}' -nfsIP na -squidIP {3} -nodes {4} -mode {5} -type {6} -nginxip {7}".format(args.domain,args.dcdomain, en_harborpassword, args.squidIP, args.nodes, args.mode, args.type, args.nginxip)
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_harborpassword], exitCode=True)
        if "Harbor Deployed successfully" in output:
            ExitCode = 0
            print("Harbor deployed successfully")
        else:
            ExitCode = 1
            print("Deploy Harbor with Custom CSR Certificate, Failed, Check the deployment of Harbor.")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1


    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
