import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
import time
import paramiko
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "commonutils", "SSHPython"))
from commonutils import SSHPython
PURPOSE = "Deploy K3S"

def remote_exec_mod(conn, cmd: str, printout=False, timeout=600, exitCodeCheck=False, printcmd=False):
    try:
        if printcmd:
            print("RUNREMOTE: %s" % cmd)
        flag, out, err = SSHPython.execute_command(client=conn, command=cmd, timeout=timeout, exitCode=exitCodeCheck)
        if printout:
            print("\n%s\n%s\n" % (out,err))
        if flag == "Fail":
            return None, out, err
        return flag, out, err
    except Exception:
        return None, out, err

def copy_k3s_images(conn):
    print("INFO: Copying the images........")
    cmd = '''
            curl -sSf -u lhcp-gateway-bot:CM@2023rock$ -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/lhcp-container-services/RPMS/20230823/lhcp-container-services-2.0-20230823.noarch.rpm
            rpm -ivh lhcp-container-services-2.0-20230823.noarch.rpm
            cp /opt/gateway/automation/bin/k3s /usr/local/bin/k3s
            chmod +x /usr/local/bin/k3s
            mkdir -p /var/lib/rancher/k3s/agent/images/ 
            rm -rf /opt/gateway/images/*kubevirt-cdi*
            rm -rf /opt/gateway/images/*kubevirt-virt*
            cp -rpf /opt/gateway/automation/k3s/images/* /var/lib/rancher/k3s/agent/images/
            cp -rpf /opt/gateway/images/pod-security-webhook-*.tgz /var/lib/rancher/k3s/agent/images/
            tar -zxvf /opt/gateway/podsecuritywebhook/pod-security-webhook.tgz -C /opt/gateway/automation
            echo "INFO: Copyied the images."
          '''
    flag, out, err = remote_exec_mod(conn, cmd, printcmd=False, printout=True)
    return True

def copy_k3s_manifests(conn):
    print("INFO: Copying the manifests........")
    cmd = '''
            mkdir -p /var/lib/kubelet/plugins_registry/
            cp -rpf /opt/gateway/automation/k3s/manifests/* /var/lib/rancher/k3s/server/manifests/ 2>/dev/null
            rm -rf /var/lib/rancher/k3s/server/manifests/cdi*
            rm -rf /var/lib/rancher/k3s/server/manifests/kubevirt*
            if [ -e "/opt/gateway/images/containers.csv" ];  then  echo "Copying images to /var/lib/rancher/k3s/agent/images...";  cat /opt/gateway/images/containers.csv | while read LINE;  do  image=$(echo $LINE |awk -F ',' '{print $4}')  type=$(echo $LINE |awk -F ',' '{print $6}')  if [ $type == local ]  then  echo "Copying images $image to /var/lib/rancher/k3s/agent/images...";  cp -rpf /opt/gateway/images/$image.tgz /var/lib/rancher/k3s/agent/images/  fi  done  fi
            gunzip -f /var/lib/rancher/k3s/agent/images/*.tgz > /dev/null
            echo "INFO: Copyied the manifests."
          '''
    flag, out, err = remote_exec_mod(conn, cmd, printcmd=False, printout=True)
    return True

def install_k3s(conn):
    print("INFO: Installing K3S with calico........")
    cmd = '''
            cat /opt/gateway/automation/scripts/k3s-install.sh | INSTALL_K3S_SKIP_DOWNLOAD=true INSTALL_K3S_SELINUX_WARN=true INSTALL_K3S_EXEC="--flannel-backend=none --disable-network-policy --cluster-cidr=10.42.0.0/16" sh -s - --disable servicelb --kube-apiserver-arg="admission-control-config-file=/opt/gateway/automation/pod-security-webhook/psa_audit_config/admission_controller.yaml" --kube-apiserver-arg="--audit-log-path=/var/lib/rancher/k3s/server/logs/audit.log" --kube-apiserver-arg="--audit-policy-file=/opt/gateway/automation/pod-security-webhook/psa_audit_config/audit.yaml" 
            sleep 60
            echo "INFO: Installed K3S with calico."
          '''
    flag, out, err = remote_exec_mod(conn, cmd, printcmd=False, printout=True)
    return True

def get_node_status(conn):
    timeout = time.time() + 60*15   # 15 minutes max wait time
    ready = False
    while True:
        cmd = "kubectl get nodes | grep Ready"
        flag, out, err = SSHPython.execute_command(conn, cmd, exitCode=True)
        if out is None:
            print("ERROR: Something went wrong, command might have timed out, please check manually")
            return None
        if out:
            if "NotReady" in out:
                print("WARN: Node is not Ready yet, will check again")
            else:
                ready = True
                break
        if time.time() > timeout:
            break
        time.sleep(5)
        print("--- Remaining time in %.2f seconds ---" % (time.time() - timeout))

    if ready:
        print("INFO: Node is Ready")
        return True
    else:
        print("ERROR: Node is not Ready")
        if err:
            print(err)
        return None

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    args = parser.parse_args()
    host = args.host
    username = args.username
    password = args.password
    
    
    client, resultFlag = SSHPython.establish_ssh_connection(host, username, password)
    if resultFlag == "Pass":
        print("SSH connection created for edge vm, Pass")
        copy_k3s_images(client)
        copy_k3s_manifests(client)
        install_k3s(client)
        output = get_node_status(client)

        if output:
            ExitCode = 0
            print("K3S deployed successfully")
        else:
            ExitCode = 1
            print("Failed to Deploy K3S")
    else:
        print("Failed to create SSH connection with edge vm")
        ExitCode = 1


    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()