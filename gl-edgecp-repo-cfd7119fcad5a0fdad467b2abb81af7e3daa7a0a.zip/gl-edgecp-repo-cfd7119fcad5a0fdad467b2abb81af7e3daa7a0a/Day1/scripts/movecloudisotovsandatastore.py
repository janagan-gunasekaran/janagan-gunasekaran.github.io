import ssl
import requests
from pyVmomi import vim, vmodl
from pyVim.connect import SmartConnect, Disconnect
import argparse
from argparse import RawTextHelpFormatter
import sys
PURPOSE = "upload iso to datastore"

def connect(hostip,username,password,httpProxyHost):
    service_instance = None
    try:
        service_instance = SmartConnect(host=hostip, user=username,pwd=password,port=443,disableSslCertValidation=True, httpProxyHost=httpProxyHost,httpProxyPort=3128)
        if not service_instance:
            service_instance = SmartConnect(host=hostip, user=username,pwd=password,port=443,disableSslCertValidation=True)
    except IOError as io_error:
        print(io_error)
    if not service_instance:
        msg = "Unable to connect to host with supplied credentials."
        return msg, False
    return service_instance, True

def find_iso_in_datastore(service_instance, datastore, vm_folder, iso_name):
    vm_folder_path = f"[{datastore.info.name}] {vm_folder}"
    iso_path = f"{vm_folder_path}/{iso_name}"
    
    try:
        browser = datastore.browser
        search_task = browser.Search(vm_folder_path)
        wait_for_task(search_task)
        
        search_results = search_task.info.result
        
        for file_info in search_results.file:
            if file_info.path == iso_name:
                return file_info
        return None
    except vim.fault.FileNotFound:
        return None

def wait_for_task(task):
    while task.info.state == vim.TaskInfo.State.running:
        pass
    return task.info.result

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-datastore_name", dest="datastore_name", help="Input datastore name: -datastore_name datastore1", type=str, default="none")
    parser.add_argument("-iso_file_path", dest="iso_file_path", help="Input iso_file_path: -iso_file_path '/root/cidata.iso'", type=str, default="none")
    parser.add_argument("-vmname", dest="vmname", help="Input vmname: -vmname edge01", type=str, default="none")
    parser.add_argument("-host", dest="host", help="Input host: -host 10.30.190.160", type=str, default="none")
    parser.add_argument("-username", dest="username", help="Input username: -username root", type=str, default="none")
    parser.add_argument("-password", dest="password", help="Input password: -password password123", type=str, default="none")
    parser.add_argument("-httpProxyHost", dest="httpProxyHost", help="Input httpProxyHost IP: -httpProxyHost 172.30.0.20", type=str, default="none")

    args = parser.parse_args()
    datastore_name=args.datastore_name
    local_file_path=args.iso_file_path
    remote_file_path=local_file_path.split('/')[-1]
    host = args.host
    vmname = args.vmname
    username = args.username
    password = args.password
    httpProxyHost = args.httpProxyHost
    ExitCode = 0
    try:
        si, status = connect(host,username,password,httpProxyHost)
        if status:
            content = si.RetrieveContent()
            datacenters_object_view = content.viewManager.CreateContainerView(content.rootFolder,[vim.Datacenter],True)
            datacenter = None
            datastore = None
            for dc_obj in datacenters_object_view.view:
                datastores_object_view = content.viewManager.CreateContainerView(dc_obj,[vim.Datastore],True)
                for ds_obj in datastores_object_view.view:
                    if ds_obj.info.name == datastore_name:
                        datacenter = dc_obj
                        datastore = ds_obj
            if not datacenter or not datastore:
                msg = "Could not find the datastore specified"
                print(msg)
                ExitCode = 1
                sys.exit(1)
            datastores_object_view.Destroy()
            datacenters_object_view.Destroy()

            existing_iso_file = find_iso_in_datastore(si, datastore, vmname, remote_file_path)
            if existing_iso_file:
                print("ISO file already exists- skipping uploading iso file")
                sys.exit(0)
            if not remote_file_path.startswith("/"):
                remote_file = f"/" + remote_file_path
            else:
                remote_file = remote_file_path
            resource = f"/folder/{vmname}" + remote_file
            #resource = "/folder" + remote_file
            params = {"dsName": datastore.info.name,
                    "dcPath": datacenter.name}
            proxies = {
                "http": f"http://{httpProxyHost}:3128",
                "https" : f"http://{httpProxyHost}:3128"
            }
            #https://10.30.194.151/folder/edge33/cidata%20-%20Copy.iso?dcPath=ha-datacenter&dsName=datastore
            http_url = f"https://{host}" + ":443" + resource + "?dcPath=" + datacenter.name + "&dsName=" + datastore.info.name
            #print(http_url)
            #print(params)
            #headers = {'Content-Type': 'application/octet-stream'}
            with open(local_file_path, "rb") as file_data:
                try:
                    response = requests.put(http_url, params=params, data=file_data, verify=False, proxies=proxies, auth=(username, password))
                    if response.status_code == 201 or response.status_code == 200:
                        ExitCode = 0
                        msg = "File uploaded successfully."
                        print(msg)
                    else:
                        msg = f"Failed to upload the file. Response status: {response.status_code}, {response.text}"
                        print(msg)
                        ExitCode = 1
                except requests.exceptions.RequestException as e:
                    msg = f"Failed to upload the file: {e}"
                    ExitCode = 1
        else:
            msg = f"Failed to connect to {host}"
            ExitCode = 1
    except vmodl.MethodFault as ex:
        msg = "Caught vmodl fault : " + ex.msg
        print(msg)
        ExitCode = 1

    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)
    
if __name__ == "__main__":
    main()