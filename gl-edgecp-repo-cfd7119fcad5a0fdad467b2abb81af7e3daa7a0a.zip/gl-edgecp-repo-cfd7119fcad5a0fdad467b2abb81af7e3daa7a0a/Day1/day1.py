#!/usr/bin/python
import json
import argparse
import subprocess
import sys
import os
import ipaddress
import shutil
from datetime import datetime
sys.path.insert(1, os.path.join(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "commonutils"))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),"commonutils", "SSHPython"))
from commonutils import SSHPython
parser = argparse.ArgumentParser()
import base64
parser.add_argument('jsonFile')
parser.add_argument('edge_id')
args = parser.parse_args()

def execute_command(cmd):
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    out, err = process.communicate()
    print("output,status_code is %s-%s"%(out, process.returncode))
    return (process.returncode, out,err)

def set_deployment_state(filepath, component, new_state):
    try:
        with open(filepath, "r") as sds:
            state_data = json.load(sds)
        state_data["components"][component] = new_state
        with open(filepath, "w") as sds:
            json.dump(state_data, sds, indent=4)
    except Exception as e:
        print(f"ERROR: {e}")

with open(args.jsonFile) as datafile:
    source_data = json.load(datafile)

#
# CREATE edge config.json
#
currentfilepath = os.path.join(os.path.dirname(os.path.abspath(__file__)))
commonutilspath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "commonutils")
target_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "commonutils", "output", "edge_config_template.json")
print(target_file_path)
with open(target_file_path, 'r') as json_file:
    output_data = json.load(json_file)
store_id = source_data["storeID"]
edge_ip = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["ipaddress"]
internalproxy = source_data["StoreInfo"]["edgecpconfigdata"]["proxyinfo"]["internal_httpproxy"]
split_parts = internalproxy.split('//')
ip_port_part = split_parts[1].split(":")
internalproxy_ip = ip_port_part[0]
edge_domain = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["storedomainname"]
dc_domain = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["dcdomainname"]
edge_user = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["username"] 
edge_password = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["password"]  
edge_vmname = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["vmname"]
primarydns = source_data["StoreInfo"]["edgecpconfigdata"]["dnsinfo"]["primarydnsserver"]

squidIP = source_data["StoreInfo"]["edgecpconfigdata"]["proxyinfo"]["httpproxy"]
split_parts = squidIP.split('//')
ip_port_part = split_parts[1].split(":")
squid_ip = ip_port_part[0]

pfSenseIP = source_data["StoreInfo"]["edgecpconfigdata"]["proxyinfo"]["pfsense_httpproxy"]
split_parts = pfSenseIP.split('//')
ip_port_part = split_parts[1].split(":")
pfsense_ip = ip_port_part[0]

if source_data["servicemapping"]["systemproxy"] == "squid":
    output_data["proxy_ip"]= squid_ip
elif source_data["servicemapping"]["systemproxy"] == "pfsense":
    output_data["proxy_ip"]= pfsense_ip

harbor_lb_ipaddr = source_data["StoreInfo"]["edgecpconfigdata"]["proxyinfo"]["harbor_nginxip"]
#coreserver = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["primaryntpserver"] 
ntp_server1 = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["primaryntpserver"] 
ntp_server2 = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["secondaryntpserver"] 
ntp_server3 = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["tertiaryntpserver"]
output_data["appname"] = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["vmname"]
output_data["ip"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["ipaddress"]
output_data["username"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["username"] 
output_data["password"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["password"]  
output_data["netmask"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["netmask"] 
output_data["gateway"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["gateway"] 
output_data["fqdn"]= f"{edge_vmname}.{edge_domain}"
output_data["dns_server1"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["ipaddress"] 

output_data["domainname"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["storedomainname"]
output_data["primarydns"]= source_data["StoreInfo"]["edgecpconfigdata"]["dnsinfo"]["primarydnsserver"]
output_data["secondarydns"]= source_data["StoreInfo"]["edgecpconfigdata"]["dnsinfo"]["secondarydnsserver"]

output_data["ntp_server1"] = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["primaryntpserver"] 
output_data["ntp_server2"] = source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["secondaryntpserver"] 
output_data["ntp_server3"]= source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["tertiaryntpserver"]
output_data["timezone"]= source_data["StoreInfo"]["edgecpconfigdata"]["ntpinfo"]["timezone"]


output_data["dcdomainname"]= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["dcdomainname"]
k3sclusterip= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["k3sclusterip"]
output_data["no_proxy"]= f"localhost,127.0.0.1,{edge_ip},*.{edge_domain},{primarydns},harbor.{edge_domain},harbor-lb.{dc_domain},pulp-lb.{dc_domain},pulp.{edge_domain},argocd-server.{edge_domain},mec.{edge_domain},{k3sclusterip},{ntp_server1}"
output_data["k3sclusterip"]= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["k3sclusterip"]
output_data["k3skubeconfigtoken"]= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["k3skubeconfigtoken"]
output_data["k3skubeconfigcert"]= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["k3skubeconfigcert"]
output_data["pdnsapi"]= source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["pdns-apikey"]
output_data["macaddress"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["edgecpmac"]
output_data["macaddress2"]= source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["edgecpmac2"]

cloudtemplates =  os.path.join(commonutilspath,"edge_templates/")
cloudconfigdest = os.path.join(commonutilspath,"output",f"{store_id}/")
scripts_filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts")
#Supports parallel store bringup
os.makedirs(cloudconfigdest, exist_ok=True)
vmtemplatefile = os.path.join(cloudconfigdest,"edge_config_template.json")
shutil.copy2(target_file_path , vmtemplatefile)
with open(vmtemplatefile, 'w') as target_file:
    json.dump(output_data, target_file, indent=4)

harborpassword = source_data["StoreInfo"]["edgecpconfigdata"]["applicationinfo"]["harboradminpassword"]
harborproxytype = source_data["servicemapping"]["harbor"]

password_bytes = harborpassword.encode("ascii")
base64_bytes = base64.b64encode(password_bytes)
en_harborPassword = base64_bytes.decode("ascii") 
argocdpassword = source_data["StoreInfo"]["edgecpconfigdata"]["applicationinfo"]["argocdadminpassword"]
confdatapath = os.path.join(commonutilspath, "config_data.json")
with open(confdatapath, 'r') as json_file:
    confdata = json.load(json_file)
csversionoct = confdata["cs_version_oct"]
csversionmar = confdata["cs_version_mar"]
rpmchecksumoct = confdata["csv_oct_checksum"]
rpmchecksummar = confdata["csv_mar_checksum"]
psaversion = confdata["psa_version"]
psaimageversion = confdata["psa_image_version"]
jfroguser = confdata["jfrog_user"]
jfrogpassword = confdata["jfrog_password"]
psa_container_image_checksum = confdata["psa_container_image_checksum"]
psa_tgz_checksum = confdata["psa_tgz_checksum"]


deploymentstatefile = f"{cloudconfigdest}/deployment-state.json"
if not os.path.isfile(deploymentstatefile):
    states = {
    "components": {
        "createcloudiso": "NOT EXECUTED",
        "movecloudisotovsandatastore": "NOT EXECUTED",
        "mountcloudisotocddrive": "NOT EXECUTED",
        "validatevm": "NOT EXECUTED",
        "deploystepca": "NOT EXECUTED",
        "deployk3s": "NOT EXECUTED",
        "deploypodsecuritywebhook": "NOT EXECUTED",
        "deploystorageclass": "NOT EXECUTED",
        "deployexternaldns": "NOT EXECUTED",
        "deploymetallb": "NOT EXECUTED",
        "deployNginxIngressController": "NOT EXECUTED",
        "deployharbor": "NOT EXECUTED",
        "harborImagePruning": "NOT EXECUTED",
        "harborChartReplication": "NOT EXECUTED",
        "setHarborCronjob": "NOT EXECUTED",
        "configurek3sregistry": "NOT EXECUTED",
        "PushImagestoHarbor": "NOT EXECUTED",
        "deploymultus": "NOT EXECUTED",
        "deployargocd": "NOT EXECUTED",
        "deploypulp": "NOT EXECUTED",
        "deployArgoworkflow": "NOT EXECUTED",
        "CreateSnowUser": "NOT EXECUTED",
        "deployldapfleet": "NOT EXECUTED"
                }
            }

    with open(deploymentstatefile, "w") as dsf:
        json.dump(states, dsf, indent=4)

with open(deploymentstatefile, "r") as dsf:
    deployment_state = json.load(dsf)
#
# CREATE ISO
#

if deployment_state["components"]["createcloudiso"] in ("NOT EXECUTED", "FAILED"):
    print("Creating Cloud ISO.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Create Cloud ISO"
        print(f"Executing command python3 {scripts_filepath}/createcloudiso.py -configfilepath {vmtemplatefile} -cloudtemplates {cloudtemplates} -cloudconfigdest {cloudconfigdest}")
        retcode, out,err = execute_command(f'python3 {scripts_filepath}/createcloudiso.py -configfilepath {vmtemplatefile} -cloudtemplates {cloudtemplates} -cloudconfigdest {cloudconfigdest}')
        if retcode != 0:
            print("ERROR: CREATE CLOUD ISO FAILED")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(retcode, file=sys.stderr)
            set_deployment_state(filepath=deploymentstatefile, component="createcloudiso", new_state="FAILED")
            sys.exit(retcode)
        else:
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print("CREATED CLOUD ISO successfully --")
            print(task,"SUCCESS")
            set_deployment_state(filepath=deploymentstatefile, component="createcloudiso", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="createcloudiso", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["createcloudiso"] == "PASSED":
    print("SKIPPING: CLOUD ISO ALREADY CREATED successfully --")

#
# move cloud iso to vsan datastore
#
if deployment_state["components"]["movecloudisotovsandatastore"] in ("NOT EXECUTED", "FAILED"):
    print("Moving cloud iso to vsan datastore.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        datastore_name = source_data["vCenter"]["vsanDatastore"]
        iso_file_path = os.path.join(commonutilspath,"output",store_id,"cidata.iso")
        host = source_data["vCenter"]["IP"]
        username = source_data["vCenter"]["username"]
        password =source_data["vCenter"]["password"]
        task="move cloud iso to vsan datastore"
        print(f"Executing command python3 {scripts_filepath}/movecloudisotovsandatastore.py -datastore_name {datastore_name} -vmname {edge_vmname} -iso_file_path {iso_file_path} -host {host} -username {username} -password XXX -httpProxyHost {internalproxy_ip}")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/movecloudisotovsandatastore.py -datastore_name {datastore_name} -vmname {edge_vmname} -iso_file_path {iso_file_path} -host {host} -username {username} -password '{password}' -httpProxyHost {internalproxy_ip}")
        if retcode != 0:
            print("ERROR: FAILED TO UPLOAD CLOUD ISO TO DATASTORE")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(retcode, file=sys.stderr)
            set_deployment_state(filepath=deploymentstatefile, component="movecloudisotovsandatastore", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("UPLOADED CLOUD ISO TO DATASTORE successfully --")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(task,"SUCCESS")
            set_deployment_state(filepath=deploymentstatefile, component="movecloudisotovsandatastore", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="movecloudisotovsandatastore", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["movecloudisotovsandatastore"] == "PASSED":
    print("SKIPPING: CLOUD ISO ALREADY UPLOADED TO DATASTORE successfully --")

#
# mount cloud iso to cddrive
#
if deployment_state["components"]["mountcloudisotocddrive"] in ("NOT EXECUTED", "FAILED"):
    print("Mounting cloud iso to vm and powering on vm.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        datastore_name = source_data["vCenter"]["vsanDatastore"]
        host = source_data["vCenter"]["IP"]
        username = source_data["vCenter"]["username"]
        password =source_data["vCenter"]["password"]
        task="MOUNT CLOUD ISO TO VM AND POWER ON VM"
        print(f"Executing command python3 {scripts_filepath}/mountcloudisotocddrive.py -datastore_name {datastore_name} -vm_name {edge_vmname} -iso_name cidata.iso -host {host} -username {username} -password XXX -httpProxyHost {internalproxy_ip}")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/mountcloudisotocddrive.py -datastore_name {datastore_name} -vm_name {edge_vmname} -iso_name cidata.iso -host {host} -username {username} -password '{password}' -httpProxyHost {internalproxy_ip}")
        if retcode != 0:
            print("ERROR: FAILED TO MOUNT CLOUD ISO TO VM AND POWER ON VM")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="mountcloudisotocddrive", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("MOUNTED CLOUD ISO TO VM AND POWERED ON VM successfully --")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(task,"SUCCESS")
            set_deployment_state(filepath=deploymentstatefile, component="mountcloudisotocddrive", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="mountcloudisotocddrive", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["mountcloudisotocddrive"] == "PASSED":
    print("SKIPPING: CLOUD ISO ALREADY MOUNTED AND VM IS POWERED ON successfully --")

#
# Validate initial VM configuration
#
if deployment_state["components"]["validatevm"] in ("NOT EXECUTED", "FAILED"):
    print("Validating initial VM configuration.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Validate initial VM configuration"
        print(f"Executing command python3 {scripts_filepath}/validatevm.py -ntpserver1 {ntp_server1} -ntpserver2 {ntp_server2} -ntpserver3 {ntp_server3} -vmname {edge_vmname} -vmip {edge_ip} -edgeuser {edge_user} -edgepassword XXX")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/validatevm.py -ntpserver1 {ntp_server1} -ntpserver2 {ntp_server2} -ntpserver3 {ntp_server3} -vmname {edge_vmname} -vmip {edge_ip} -edgeuser {edge_user} -edgepassword '{edge_password}'")
        if retcode != 0:
            print("ERROR: FAILED to Validate initial VM configuration")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="validatevm", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Validate initial VM configuration successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="validatevm", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="validatevm", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["validatevm"] == "PASSED":
    print("SKIPPING: ALREADY VALIDATED INITIAL VM CONFIGURATION successfully --")

#
# Deploy Step-ca
#
if deployment_state["components"]["deploystepca"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying step CA.....")
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    primarydns =  k3sclusterip #pfsense wancorp IP
    #primarydns =  source_data["StoreInfo"]["edgecpconfigdata"]["dnsinfo"]["primarydnsserver"]
    #core_server = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["core-server"]+"."+dc_domain
    core_server = ntp_server1 #FSE node 1 IP
    root_fingerprint = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["root-fingerprint"]
    root_cert = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["root-cert"]
    root_key = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["root-key"]
    intermediate_cert = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["intermediate-cert"]
    intermediate_key = source_data["StoreInfo"]["edgecpconfigdata"]["secretinfo"]["intermediate-key"]
    pdnsapikey =  source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["pdns-apikey"]
    try:
        task="Deploy Step-ca"
        print(f"Executing command python3 {scripts_filepath}/deploystepca.py -host {edge_ip} -username {edge_user} -password XXX -dnsserver {primarydns} -dnsdomain {dc_domain} -coreserver {core_server} -corefingerprint XXX -rootcert XXX -rootkey XXX -intermediatecert XXX -intermediatekey XXX -pdnsapikey XXX")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploystepca.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -dnsserver {primarydns} -dnsdomain {dc_domain} -coreserver {core_server} -corefingerprint {root_fingerprint} -rootcert {root_cert} -rootkey {root_key} -intermediatecert {intermediate_cert} -intermediatekey {intermediate_key} -pdnsapikey {pdnsapikey}")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Step-ca")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(retcode, file=sys.stderr)
            set_deployment_state(filepath=deploymentstatefile, component="deploystepca", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Step-ca successfully --")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            print(task,"SUCCESS")
            set_deployment_state(filepath=deploymentstatefile, component="deploystepca", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploystepca", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploystepca"] == "PASSED":
    print("SKIPPING: STEP-CA ALREADY DEPLOYED successfully --")

#
# Deploy K3S
#
if deployment_state["components"]["deployk3s"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying K3S------------------")
    
    try:
        task="Deploy K3S"
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        print(f"Executing command python3 {scripts_filepath}/deployk3s.py -host {edge_ip} -username {edge_user} -password XXX -csversionoct {csversionoct} -csversionmar {csversionmar} -rpmchecksumoct {rpmchecksumoct} -rpmchecksummar {rpmchecksummar} -psaversion {psaversion} -psaimageversion {psaimageversion} -jfroguser {jfroguser} -jfrogpassword XXX -psacontimg {psa_container_image_checksum} -psatgzchecksum {psa_tgz_checksum}")
        retcode,out,err = execute_command(f"python3 {scripts_filepath}/deployk3s.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -csversionoct {csversionoct} -csversionmar {csversionmar} -rpmchecksumoct '{rpmchecksumoct}' -rpmchecksummar '{rpmchecksummar}' -psaversion {psaversion} -psaimageversion {psaimageversion} -jfroguser {jfroguser} -jfrogpassword '{jfrogpassword}' -psacontimg '{psa_container_image_checksum}' -psatgzchecksum '{psa_tgz_checksum}'")

        if retcode != 0:
            print("ERROR: FAILED to Deploy K3S")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployk3s", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed K3S successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployk3s", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployk3s", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployk3s"] == "PASSED":
    print("SKIPPING: K3S ALREADY DEPLOYED successfully --")

#
# Deploy POD SECURITY WEBHOOK
#
if deployment_state["components"]["deploypodsecuritywebhook"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying POD SECURITY WEBHOOK------------------")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploy POD SECURITY WEBHOOK"
        print(f"Executing command python3 {scripts_filepath}/deploypodsecuritywebhook.py -host {edge_ip} -username {edge_user} -password XXX")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploypodsecuritywebhook.py -host {edge_ip} -username {edge_user} -password '{edge_password}'")
        if retcode != 0:
            print("ERROR: FAILED to Deploy POD SECURITY WEBHOOK")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploypodsecuritywebhook", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed POD SECURITY WEBHOOK successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploypodsecuritywebhook", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploypodsecuritywebhook", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploypodsecuritywebhook"] == "PASSED":
    print("SKIPPING: POD SECURITY WEBHOOK ALREADY DEPLOYED successfully --")

#
# Deploy Storage class
#
if deployment_state["components"]["deploystorageclass"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Storage class.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploy Storage class"
        print(f"Executing command python3 {scripts_filepath}/deploystorageclass.py -host {edge_ip} -username {edge_user} -password XXX -mode install -type singlenode")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploystorageclass.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -mode install -type singlenode")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Storage class")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploystorageclass", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Storage class successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploystorageclass", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploystorageclass", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploystorageclass"] == "PASSED":
    print("SKIPPING: STORAGE CLASS ALREADY DEPLOYED successfully --")

#
# Deploy ExternalDNS
#

def get_ptr_domain():
    mask = source_data["StoreInfo"]["edgecpconfigdata"]["networkinfo"]["netmask"] 
    gw_ip = edge_ip
    try:
        ipBin = ''.join([bin(int(x) + 256)[3:] for x in gw_ip.split('.')])
        maskBin = ''.join([bin(int(x) + 256)[3:] for x in mask.split('.')])
        gwBin = ''.join(chr(ord(a) & ord(b)) for a, b in zip(ipBin, maskBin))
        calcGW = '.'.join([str(int(gwBin[0:8], 2)), str(int(gwBin[8:16], 2)), str(
            int(gwBin[16:24], 2)), str(int(gwBin[24:32], 2))])
        ipnetwork = calcGW + "/" + mask
        GW = str(ipaddress.ip_network(ipnetwork)).split("/")[0]
        mask = str(ipaddress.ip_network(ipnetwork)).split("/")[-1]
        reverseLookup=""
        if int(mask) >= 24:
            print("Mask greater than or qual to 24")
            reverseLookup='.'.join((GW.split('.')[::-1])[1:])
        elif int(mask) >=16 and int(mask) < 24:
            print("Mask in between 16 and 24")
            reverseLookup='.'.join((GW.split('.')[::-1])[2:])
        else:
            print("Mask than or qual to 16")
            reverseLookup='.'.join((GW.split('.')[::-1])[3:])
        return str(reverseLookup+".in-addr.arpa")
    except Exception:
        print("exception")
        return ""

if deployment_state["components"]["deployexternaldns"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying ExternalDNS.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        dcdomain = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["dcdomainname"]
        pdns_hostip = edge_ip
        dcpdns_hostip = k3sclusterip
        pdns_apiKey = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["pdns-apikey"]
        dcpdns_apiKey = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["pdns-apikey"]
        PTRDOMAINLINES = get_ptr_domain()
        task="Deploy ExternalDNS"
        print(f"Executing command python3 {scripts_filepath}/deployexternaldns.py -host {edge_ip} -username {edge_user} -password XXX -domain {edge_domain} -pdns_hostip {pdns_hostip} -dcpdns_hostip {dcpdns_hostip} -dcdomain {dcdomain} -pdns_apiKey {pdns_apiKey} -dcpdns_apiKey {dcpdns_apiKey} -mode install -type edge -PTRDOMAINLINES {PTRDOMAINLINES}")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deployexternaldns.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -domain {edge_domain} -pdns_hostip {pdns_hostip} -dcpdns_hostip {dcpdns_hostip} -dcdomain {dcdomain} -pdns_apiKey {pdns_apiKey} -dcpdns_apiKey {dcpdns_apiKey} -mode install -type edge -PTRDOMAINLINES {PTRDOMAINLINES}")
        if retcode != 0:
            print("ERROR: FAILED to Deploy ExternalDNS")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployexternaldns", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed ExternalDNS successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployexternaldns", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployexternaldns", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployexternaldns"] == "PASSED":
    print("SKIPPING: EXTERNALDNS ALREADY DEPLOYED successfully --")

#
# Deploy Metallb
#
#python3 ./Day1/scripts/Deploymetallb.py -host {} -username {} -password {} -startIp {}  -endIp {} -mode {} -type {}
if deployment_state["components"]["deploymetallb"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Metallb.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        startIp = source_data["StoreInfo"]["edgecpconfigdata"]["applicationinfo"]["metallb"]["startip"]
        endIp = source_data["StoreInfo"]["edgecpconfigdata"]["applicationinfo"]["metallb"]["endip"]
        task="Deploy Metallb"
        print(f"Executing command python3 {scripts_filepath}/deploymetallb.py -host {edge_ip} -username {edge_user} -password XXX -startIp {startIp} -endIp {endIp} -mode install -type singlenode")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploymetallb.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -startIp {startIp} -endIp {endIp} -mode install -type singlenode")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Metallb")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploymetallb", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Metallb successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploymetallb", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploymetallb", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploymetallb"] == "PASSED":
    print("SKIPPING: METALLB ALREADY DEPLOYED successfully --")

#
# Deploy Nginx Ingress Controller
#
if deployment_state["components"]["deployNginxIngressController"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Nginx.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploy Nginx Ingress Controller"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd = "python3 /opt/gateway/automation/container-services/nginx/deployNginxIngressController.py -mode install -type edge"
            print(f"Executing command {cmd}")
            status, output, error = SSHPython.execute_command(client, cmd)
            if "Nginx Ingress Controller Deployed Successfully" in output or "Skipping Nginx ingress deployment as it is already deployed" in output:
                retcode = 0
            else:
                retcode = 1    
        if retcode != 0:
            print("ERROR: FAILED to Deploy Nginx Ingress Controller")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployNginxIngressController", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Nginx Ingress Controller successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployNginxIngressController", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployNginxIngressController", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployNginxIngressController"] == "PASSED":
    print("SKIPPING: NGINX INGRESS CONTROLLER ALREADY DEPLOYED successfully --")

#
# Deploy Harbor
#

nodes = "/opt/gateway/automation/container-services/conf/nodes.json"
if deployment_state["components"]["deployharbor"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Harbor.....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploy Harbor"
        print(f"Executing command python3 {scripts_filepath}/deployharbor.py -host {edge_ip} -username {edge_user} -password XXX -harborpassword XXX -nodes {nodes} -domain {edge_domain} -dcdomain {dc_domain} -squidIP {squid_ip} -mode install -type edge -nginxip {harbor_lb_ipaddr}")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deployharbor.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -harborpassword '{harborpassword}' -nodes {nodes} -domain {edge_domain} -dcdomain {dc_domain} -squidIP {squid_ip} -mode install -type edge -nginxip {harbor_lb_ipaddr}")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Harbor")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployharbor", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Harbor successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployharbor", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployharbor", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployharbor"] == "PASSED":
    print("SKIPPING: HARBOR ALREADY DEPLOYED successfully --")

#
# Create Harbor Image Pruning
#
if deployment_state["components"]["harborImagePruning"] in ("NOT EXECUTED", "FAILED"):
    print("Creating Harbor Image Pruning....")
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    try:
        task="Create Harbor Image Pruning"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd = "python3 /opt/gateway/automation/container-services/harbor/harborImagePruning.py -domain {0} -harboruser {1} -harborpassword '{2}' -type {3} -projectname {4}".format(edge_domain, 'admin', en_harborPassword, 'edge', 'library')
            print(f"Executing command {cmd}")
            status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_harborPassword], exitCode=True)
            if ("created successfully." in output) or ("configured." in output) or ("Rule already exist" in output):
                retcode = 0
            else:
                retcode = 1
        if retcode != 0:
            print("ERROR: FAILED to Create Harbor Retention policy")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="harborImagePruning", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Retention policy created successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="harborImagePruning", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="harborImagePruning", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["harborImagePruning"] == "PASSED":
    print("SKIPPING: HARBOR RETENTION POLICY ALREADY CREATED successfully --")

#
# Create Harbor Chart Replication policy
#
if deployment_state["components"]["harborChartReplication"] in ("NOT EXECUTED", "FAILED"):
    print("Creating Harbor Replication policy....")
    dcharborpassword = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["dcharborpassword"]
    password_bytes = dcharborpassword.encode("ascii")
    base64_bytes = base64.b64encode(password_bytes)
    en_dcharborPassword = base64_bytes.decode("ascii") 
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    try:
        task="Create Harbor Chart Replication policy"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")

            cmd = "python3 /opt/gateway/automation/container-services/harbor/harborChartReplication.py -dcdomain {0} -edgedomain {1} -dcharboruser {2} -dcharborpassword '{3}' -edgeharboruser {4} -edgeharborpassword '{5}' -edgeprojectname {6} -proxytype '{7}'".format(dc_domain, edge_domain, 'admin', en_dcharborPassword, 'admin',en_harborPassword, 'library', harborproxytype)
            print(f"Executing command {cmd}")
            status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_dcharborPassword, en_harborPassword], exitCode=True)
        if status != "Pass":
            print("ERROR: FAILED to Create Harbor Replication policy")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="harborChartReplication", new_state="FAILED")
            sys.exit(1)
        else:
            print("Replication policy ran successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="harborChartReplication", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="harborChartReplication", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["harborChartReplication"] == "PASSED":
    print("SKIPPING: HARBOR REPLICATION POLICY ALREADY CREATED successfully --")


#
# Set Harbor Chart Replication cronjob
#
if deployment_state["components"]["setHarborCronjob"] in ("NOT EXECUTED", "FAILED"):
    print("Set Harbor Chart Replication cronjob....")
    dcharborpassword = source_data["StoreInfo"]["edgecpconfigdata"]["dcclusterinfo"]["dcharborpassword"]
    password_bytes = dcharborpassword.encode("ascii")
    base64_bytes = base64.b64encode(password_bytes)
    en_dcharborPassword = base64_bytes.decode("ascii") 
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    try:
        task="Set Harbor Chart Replication cronjob"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")

            cmd = "python3 /opt/gateway/automation/container-services/harbor/setHarborCronjob.py -dcdomain {0} -edgedomain {1} -dcharboruser {2} -dcharborpassword '{3}' -edgeharboruser {4} -edgeprojectname {5} -proxytype '{6}'".format(dc_domain, edge_domain, 'admin', en_dcharborPassword, 'admin', 'library', harborproxytype)
            print(f"Executing command {cmd}")
            status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_dcharborPassword, en_harborPassword], exitCode=True)
        if status != "Pass":
            print("ERROR: FAILED to Create Harbor Replication cronjob")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="setHarborCronjob", new_state="FAILED")
            sys.exit(1)
        else:
            print("Replication policy cronjob created successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="setHarborCronjob", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="setHarborCronjob", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["setHarborCronjob"] == "PASSED":
    print("SKIPPING: HARBOR REPLICATION POLICY ALREADY CREATED successfully --")


#
# Configurek3sregistry
#
if deployment_state["components"]["configurek3sregistry"] in ("NOT EXECUTED", "FAILED"):
    print("Configure k3s registry....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task= "Configure k3s registry"
        nodes = "/opt/gateway/automation/container-services/conf/nodes.json"
        print(f"Executing command python3 {scripts_filepath}/configurek3sregistry.py -host {edge_ip} -username {edge_user} -password XXX -domain {edge_domain} -nodes {nodes} -mode install -type singlenode")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/configurek3sregistry.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -domain {edge_domain} -nodes {nodes} -mode install -type singlenode")
        if retcode != 0:
            print("ERROR: FAILED to Configure k3s registry")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="configurek3sregistry", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Configured k3s registry successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="configurek3sregistry", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="configurek3sregistry", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["configurek3sregistry"] == "PASSED":
    print("SKIPPING: K3S REGISTRY ALREADY CONFIGURED successfully --")

#
# Push Images to harbor
#
if deployment_state["components"]["PushImagestoHarbor"] in ("NOT EXECUTED", "FAILED"):
    print("Push Images to harbor....")
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    fpath = "/opt/gateway/images/"
    image_list = ["argocd","dex","alpine","argocli","pulp","multus","whereabouts","workflow","openldap","argoexec","busybox"]
    image_str=" ".join(image_list)
    print("image_str",image_str)
    try:
        print("Deploying Push Images to harbor....")
        task="Deploy  Push Images to harbor"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd_p = f"python3 /opt/gateway/automation/container-services/harbor/PushImagestoHarbor.py -domain {edge_domain} -harborPassword XXX -fpath {fpath} -imagelist {image_str}"
            print(f"Executing command {cmd_p}")
            cmd = "python3 /opt/gateway/automation/container-services/harbor/PushImagestoHarbor.py -domain {0} -harborPassword '{1}' -fpath {2} -imagelist {3}".format(edge_domain, en_harborPassword, fpath, image_str)
            status, output, error = SSHPython.execute_command(client, cmd, passwords=[en_harborPassword], timeout=3000)
            if "Pushed images into Harbor successfully" in output:
                retcode = 0
            else:
                retcode = 1
        if retcode != 0:
            print("ERROR: FAILED to Deploy Push Images to harbor")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="PushImagestoHarbor", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Push Images to harbor successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="PushImagestoHarbor", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="PushImagestoHarbor", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["PushImagestoHarbor"] == "PASSED":
    print("SKIPPING: PUSH IMAGE TO HARBOR ALREADY DEPLOYED successfully --")

#
# Deploy Multus
#
if deployment_state["components"]["deploymultus"] in ("NOT EXECUTED", "FAILED"):
    print("Multus CNI DEPLOYMENT------------------")
    nodes = "/opt/gateway/automation/container-services/conf/nodes.json"
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    try:
        task="Deploy Multus"
        print(f"Executing command python3 {scripts_filepath}/deploymultus.py -host {edge_ip} -username {edge_user} -password XXX -nodes {nodes} -domain {edge_domain} -mode install -type singlenode")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploymultus.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -nodes {nodes} -domain {edge_domain} -mode install -type singlenode")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Multus")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploymultus", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Multus successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploymultus", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploymultus", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploymultus"] == "PASSED":
    print("SKIPPING: MULTUS CNI ALREADY DEPLOYED successfully --")

#
# Deploy Argocd
#
if deployment_state["components"]["deployargocd"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Argocd....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploy Argocd"
        print(f"Executing command python3 {scripts_filepath}/deployargocd.py -host {edge_ip} -username {edge_user} -password XXX -harborpassword XXX -argocdpassword XXX -domain {edge_domain} -env integ -squidIP {squid_ip} -mode install -type edge -dcdomainname {dc_domain} -storeID {store_id}")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deployargocd.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -harborpassword '{harborpassword}' -argocdpassword '{argocdpassword}' -domain {edge_domain} -env integ -squidIP {squid_ip} -mode install -type edge -dcdomainname {dc_domain} -storeID {store_id}")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Argocd")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployargocd", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Argocd successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployargocd", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployargocd", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployargocd"] == "PASSED":
    print("SKIPPING: ARGOCD ALREADY DEPLOYED successfully --")

#
# Deploy pulp
#
if deployment_state["components"]["deploypulp"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Pulp....")
    httpProxy = f"http://{squid_ip}:3128"
    httpsProxy = f"http://{squid_ip}:3128"
    pulpPassword = source_data["StoreInfo"]["edgecpconfigdata"]["applicationinfo"]["pulpadminpassword"]
    nodes = "/opt/gateway/automation/container-services/conf/nodes.json"
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Start Time: {formatted_time}")
    try:
        task="Deploy Pulp"
        print(f"Executing command python3 {scripts_filepath}/deploypulp.py -host {edge_ip} -username {edge_user} -password XXX -pulpPassword XXX -domain {edge_domain} -nodes {nodes} -squidIP {squid_ip} -mode install -type edge")
        retcode, out,err = execute_command(f"python3 {scripts_filepath}/deploypulp.py -host {edge_ip} -username {edge_user} -password '{edge_password}' -pulpPassword '{pulpPassword}' -domain {edge_domain} -nodes {nodes} -squidIP {squid_ip} -mode install -type edge")
        if retcode != 0:
            print("ERROR: FAILED to Deploy Pulp")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploypulp", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Pulp successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deploypulp", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deploypulp", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deploypulp"] == "PASSED":
    print("SKIPPING: PULP ALREADY DEPLOYED successfully --")

#
# Deploy Argoworkflow
#
if deployment_state["components"]["deployArgoworkflow"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying Argoworkflow....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploying Argoworkflow"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd_p = f"python3 /opt/gateway/automation/container-services/argoworkflow/deployArgoworkflow.py -domain {edge_domain} -type edge -mode install"
            print(f"Executing command {cmd_p}")
            status, output, error = SSHPython.execute_command(client, cmd_p)
            if "ArgoWorkflow Deployed Successfully" in output:
                retcode = 0
            else:
                retcode = 1
        if retcode != 0:
            print("ERROR: FAILED to Deploy Argoworkflow")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployArgoworkflow", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed Argoworkflow successfully")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployArgoworkflow", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployArgoworkflow", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployArgoworkflow"] == "PASSED":
    print("SKIPPING: ARGOWORKFLOW ALREADY DEPLOYED successfully --")

#
# create snow user
#
#python3 /opt/gateway/scripts/CreateSnowUser.py
if deployment_state["components"]["CreateSnowUser"] in ("NOT EXECUTED", "FAILED"):
    print("Creating snow user....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="create snow user"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd = "python3 /opt/gateway/scripts/CreateSnowUser.py"
            print(f"Executing command {cmd}")
            status, output, error = SSHPython.execute_command(client, cmd, exitCode=True)
            if "CreateSnowUser : Passed" in output:
                retcode = 0
            else:
                retcode = 1
        if retcode != 0:
            print("ERROR: FAILED to create snow user")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="CreateSnowUser", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("created snow user successfully --")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="CreateSnowUser", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="CreateSnowUser", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["CreateSnowUser"] == "PASSED":
    print("SKIPPING: SNOW USER ALREADY CREATED successfully --")

#
# Fleet pre-req for LDAP
#
if deployment_state["components"]["deployldapfleet"] in ("NOT EXECUTED", "FAILED"):
    print("Deploying LDAP PRE-REQUISITES....")
    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"Start Time: {formatted_time}")
        task="Deploying LDAP PRE-REQUISITES"
        client, resultFlag = SSHPython.establish_ssh_connection(edge_ip, edge_user, edge_password)
        if resultFlag == "Pass":
            print("SSH connection created for edge vm, Pass")
            cmd_p = f"python3 /opt/gateway/automation/container-services/fleetprerequisites/deployldapfleet.py -domain {edge_domain} -type edge"
            print(f"Executing command {cmd_p}")
            status, output, error = SSHPython.execute_command(client, cmd_p)
            if "LDAP Pre-requisites Deployed Successfully" in output:
                retcode = 0
            else:
                retcode = 1
        if retcode != 0:
            print("ERROR: FAILED to Deploy LDAP PRE-REQUISITES")
            print(retcode, file=sys.stderr)
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployldapfleet", new_state="FAILED")
            sys.exit(retcode)
        else:
            print("Deployed LDAP PRE-REQUISITES successfully")
            print(task,"SUCCESS")
            current_time = datetime.now()
            formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"Complete Time: {formatted_time}")
            set_deployment_state(filepath=deploymentstatefile, component="deployldapfleet", new_state="PASSED")
    except OSError as e:
        print("Execution failed:", e, file=sys.stderr)
        print(task,e)
        set_deployment_state(filepath=deploymentstatefile, component="deployldapfleet", new_state="FAILED")
        sys.exit(e)
elif deployment_state["components"]["deployldapfleet"] == "PASSED":
    print("SKIPPING: LDAP PRE-REQUISITES ALREADY DEPLOYED successfully --")
