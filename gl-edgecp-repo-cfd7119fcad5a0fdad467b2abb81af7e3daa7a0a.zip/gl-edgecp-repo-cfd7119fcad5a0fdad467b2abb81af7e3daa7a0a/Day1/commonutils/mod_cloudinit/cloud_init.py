import logging
import os
import argparse
import sys
from typing import Union
import jinja2
import json
import subprocess


class RenderTemplates(object):

    def __init__(self, json_filepath, template_dir, output_dir):
        """
        class RenderTemplate generate output file based on the formatted template render on a given value

        Input:
        --------------
        json_filepath: [str] Filepath of a json file
        template_dir: [str] Directory location of jinja template files
        output_dir: [str] Path of the output directory to store output file rendered from templates
        --------------
        """
        self.json_filepath = json_filepath
        self.template_dir = template_dir
        self.output_dir = output_dir
        self.values_obj = self.load_json

    def __repr__(self):
        return 'RenderTemplates({},{},{})'.format(self.json_filepath, self.template_dir, self.output_dir)

    def __str__(self):
        return f'json_file-{self.json_filepath}, template_dir-{self.template_dir}, output_dir-{self.output_dir}'

    @property
    def check_inputs(self):
        if not os.path.isfile(r'{}'.format(os.path.abspath(self.json_filepath))):
            sys.exit(f"Json filepath provided \'{self.json_filepath}\' doesn't exist!")
        else:
            print(f"\tPath: \'{self.json_filepath}\' exist!")

        if not os.path.isdir(r'{}'.format(os.path.abspath(self.template_dir))):
            sys.exit(f"Template path: \'{self.template_dir}\' doesn't exist!")
        else:
            print(f"\tTemplate path: \'{self.template_dir}\' exist!")

        if not os.path.isdir(r'{}'.format(os.path.abspath(self.output_dir))):
            try:
                os.makedirs(r'{}'.format(os.path.abspath(self.output_dir)))
                print(f"\tOutput path: \'{self.output_dir}\' created")
            except IOError:
                raise IOError(f"Path \'{self.output_dir}\' doesn't exist!")
        else:
            print(f"\tOutput path: \'{self.output_dir}\' exist!")

        return True

    @property
    def load_json(self):
        """
        Load Json files having values defined for template file
        """
        try:
            with open(r'{}'.format(os.path.join(self.json_filepath)), 'r', encoding='utf-16') as reader:
                json_obj = json.load(reader)
        except OSError:
            print('Error reading file', self.json_filepath)
            raise OSError('Error reading file', self.json_filepath)
        except UnicodeError:
            try:
                with open(r'{}'.format(os.path.join(self.json_filepath)), 'r') as reader:
                    json_obj = json.load(reader)
            except UnicodeError:
                raise UnicodeError('Error reading file', self.json_filepath)
            else:
                return json_obj
        except Exception as e:
            print('Error in loading input json file')
            raise e
        else:
            return json_obj

    @property
    def add_ssh_key(self):
        """
        Add/generate the ssh-key to json file obj
        """
        if os.path.isfile(os.path.expanduser("~/.ssh/id_rsa.pub")):
            with open(os.path.expanduser("~/.ssh/id_rsa.pub"), "r") as reader:
                self.values_obj["build_server_public_key"] = reader.read()
            return self.values_obj["build_server_public_key"]
        else:
            try:
                root_dir = os.path.expanduser("~/.ssh/id_rsa")
                subprocess.check_call(['ssh-keygen', '-C', '', '-P', '', '-f', root_dir])
            except subprocess.CalledProcessError:
                print("RSA-key can't be generated!")
            except OSError:
                print("RSA-key can't be generated!")
            else:
                with open(os.path.expanduser("~/.ssh/id_rsa.pub"), "r") as reader:
                    self.values_obj["build_server_public_key"] = reader.read()
                return self.values_obj["build_server_public_key"]
            finally:
                self.values_obj["build_server_public_key"] = ''
                return self.values_obj["build_server_public_key"]

    def render_file(self, template_filepath, output_filepath):
        """
        Writes formatted output file based on the input template
        Input:
        -------------
        template_filepath: [str]
        output_filepath: [str]
        -------------
        """
        print(f"using template {template_filepath} to create output {output_filepath}")
        try:
            with open(template_filepath, "r") as temp:
                template_data = temp.read()
                t = jinja2.Template(template_data)
        except KeyError:
            raise KeyError(f'Error in template file {template_filepath}')
        except FileNotFoundError:
            raise FileNotFoundError(f'File {template_filepath} not found!')
        else:
            try:
                os.makedirs(os.path.dirname(self.output_dir), exist_ok=True)
                os.umask(0)
                with open(output_filepath, 'w') as writer:
                    writer.write(t.render(self.values_obj))
                # print(f"using template {template_filepath} created output {output_filepath}")
            except TypeError:
                raise TypeError(f'File {output_filepath} can\'t created for template file {template_filepath}')
            except IOError:
                raise IOError("Error occurred!!")
            except Exception as e:
                raise e

    def get_template_filepath(self):
        """
        To check for given template filename present or not in the templates directory.

        Return:
             dict having key as template filename and values as template filepath.
        """
        input_files = {}
        for root, dirs, files in os.walk(os.path.join(self.template_dir)):
            for name in files:
                input_files[name] = os.path.join(root, name)

        return input_files

def check_user_permission(filepath):
    """
    Return permission in integer given to a filename.
    """
    st = os.stat(r'{}'.format(filepath))
    return oct(st.st_mode)[-3:]


def main():
    """
    Main function
    """
    parser = argparse.ArgumentParser(description='Required named arguments')
    parser.add_argument(
        "-v", action="store", dest="values", help="JSON Input file", type=str, required=True
    )
    parser.add_argument(
        "-t",
        action="store",
        dest="template",
        help="Input template file",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-o", action="store", dest="output", help="Output file", type=str, required=True
    )

    parser.parse_args()
    values_file = parser.parse_args().values
    template_dir = parser.parse_args().template
    output_dir = parser.parse_args().output

    if not os.path.isfile(r'{}'.format(os.path.abspath(values_file))):
        logging.info(f"\tJson file path: \'{values_file}\' doesn't exist, provide file path for argument -v")
        sys.exit(f"Json file path \'{values_file}\' doesn't exist, provide val path for argument -v")
    else:
        logging.info(f"\tPath: \'{values_file}\' exist!")

    if not os.path.isdir(r'{}'.format(os.path.abspath(template_dir))):
        logging.info(f"\tTemplate path: \'{template_dir}\' doesn't exist, provide correct path for argument -o")
        sys.exit(f"Template path: \'{template_dir}\' doesn't exist, provide valid path for argument -t")
    else:
        logging.info(f"\tTemplate path: \'{template_dir}\' exist!")

    if not os.path.isdir(r'{}'.format(os.path.abspath(output_dir))):
        try:
            os.makedirs(r'{}'.format(os.path.abspath(output_dir)))
            logging.info(f"\tOutput path: \'{output_dir}\' created")
        except IOError:
            logging.info(f"\tPath: \'{output_dir}\' is doesn't exist, provide valid path for argument -o")
            raise IOError(f"Path \'{output_dir}\' doesn't exist, provide valid path for argument -o")
    else:
        logging.info(f"\tOutput path: \'{output_dir}\' exist!")

    obj_render = RenderTemplates(values_file, template_dir, output_dir)
    if not obj_render.add_ssh_key:
        logging.info("\tssh-key is not found!")
        print("ssh-key not found!")

    dict_templates = obj_render.get_template_filepath()
    if len(dict_templates):
        for name, template_dir in dict_templates.items():
            output_filepath = os.path.join(obj_render.output_dir, name)
            obj_render.render_file(template_dir, output_filepath)
    else:
        logging.info("\tNo template files found at provided template location!")


if __name__ == "__main__":
    script_path = os.path.dirname(os.path.abspath(__file__))
    print(f'Script path: {script_path}')
    log_path = os.path.join(script_path, 'execution.log')
    logging.basicConfig(
        filename=r'{}'.format(log_path),
        format="%(levelname)s: %(asctime)s %(message)s",
        filemode='w',
        level=logging.INFO)
    main()
    logging.info('\tScript executed!')
    print(f"Script executed!, log written in file at location: {log_path}")