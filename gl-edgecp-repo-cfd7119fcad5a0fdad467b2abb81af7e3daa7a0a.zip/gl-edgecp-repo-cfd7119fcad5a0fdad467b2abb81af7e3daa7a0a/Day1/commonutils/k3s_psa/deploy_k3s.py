import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
import time
import paramiko
import logging
from lib import commonutil

PURPOSE = "Deploy K3S"

def install_containerservice_rpm(csversion, jfroguser, jfrogpassword, rpmchecksum):
    print("INFO: Copying the container service rpm........")
    logging.info("INFO: Copying the container service rpm........")
    curl_cmd = f"curl -sSf -u {jfroguser}:{jfrogpassword} -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/lhcp-container-services/RPMS/{csversion}/lhcp-container-services-2.0-{csversion}.noarch.rpm"
    pwd_encrypted_curl_cmd = f"curl -sSf -u XXX:XXX -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/lhcp-container-services/RPMS/{csversion}/lhcp-container-services-2.0-{csversion}.noarch.rpm"
    checksum_cmd = f"sha256sum lhcp-container-services-2.0-{csversion}.noarch.rpm | cut -d' ' -f1"
    status1 = execute_curl_with_retry(curl_cmd, checksum_cmd, rpmchecksum, pwd_encrypted_curl_cmd)
    if status1:
        cmd = f"rpm -qa |grep lhcp-container-services"
        print("Checking if container servcies rpm is already installed:", cmd)
        logging.info("INFO: Checking if container servcies rpm is already installed........")
        flag, out, err = commonutil.execute_command(cmd)
        if f"{csversion}" in out:
            cmd = f"rpm -e lhcp-container-services-develop"
            print("Removing existing container services rpm", cmd)
            logging.info("INFO: Removing existing container services rpm........")
            flag, out, err = commonutil.execute_command(cmd)
        cmd = f"rpm -Uvh lhcp-container-services-2.0-{csversion}.noarch.rpm"
        print("Executing the command:", cmd)
        flag, out, err = commonutil.execute_command(cmd)
        cmd = f"rpm -qa |grep lhcp-container-services"
        print("Executing the command:", cmd)
        flag, out, err = commonutil.execute_command(cmd)
        if f"{csversion}" in out:
            print("Installed Container Services rpm sucessfully")
            logging.info("Installed Container Services rpm sucessfully")
            return True
    else:
        return False

def execute_curl_with_retry(curl_cmd, checksum_cmd, checksum, pwd_encrypted_curl_cmd):
    max_retries = 5
    for retry_count in range(1,max_retries + 1):
        print(f"Trial No : {retry_count}")
        print("Executing command: ", pwd_encrypted_curl_cmd)
        flag1, out1, err1 = commonutil.execute_command(curl_cmd)
        if flag1 == 0:
            print("File downloaded.")
            print("Executing command: ", checksum_cmd)
            flag1, out1, err1 = commonutil.execute_command(checksum_cmd)
            if flag1 == 0 and out1.strip() == checksum.strip():
                print("Checksum validated and file downloaded successfully.")
                logging.info("Checksum validated and file downloaded successfully.")
                return True
            else:
                print("Checksum validation failed.")
                logging.error ("Checksum validation failed.")
                return False
    else:
        print("Retry counts exceeded for checksum validation. Exiting.")
        logging.info("Retry counts exceeded for checksum validation. Exiting.")
        return False


def download_psa_files(psaversion, psaimageversion, jfroguser, jfrogpassword, psacontimg, psatgzchecksum):
    print("INFO: Downloading pod security webhook files and images........")
    logging.info("INFO: Downloading pod security webhook files and images........")
    cmd = f"rm /opt/gateway/podsecuritywebhook/pod-security-webhook.tgz && rm /opt/gateway/images/pod-security-webhook-*.tgz"
    print("Executing the command:", cmd)
    flag, out, err = commonutil.execute_command(cmd)
    
    curl_cmd = f"cd /opt/gateway/podsecuritywebhook/ && curl -sSf -u {jfroguser}:{jfrogpassword} -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/Container-Images/{psaversion}/publish/pod-security-webhook/pod-security-webhook.tgz"
    pwd_encrypted_curl_cmd = f"cd /opt/gateway/podsecuritywebhook/ && curl -sSf -u XXX:XXX -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/Container-Images/{psaversion}/publish/pod-security-webhook/pod-security-webhook.tgz"
    checksum_cmd = f"cd /opt/gateway/podsecuritywebhook/ && sha256sum pod-security-webhook.tgz | cut -d' ' -f1"
    status1 = execute_curl_with_retry(curl_cmd, checksum_cmd, psatgzchecksum, pwd_encrypted_curl_cmd)

    curl_cmd = f"cd /opt/gateway/images/ && curl -sSf -u {jfroguser}:{jfrogpassword} -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/Container-Images/{psaversion}/publish/container-images/pod-security-webhook-{psaimageversion}.tgz"
    pwd_encrypted_curl_cmd = f"cd /opt/gateway/images/ && curl -sSf -u XXX:XXX -O https://hcss.jfrog.io/artifactory/lhcp-sles-repo/Container-Images/{psaversion}/publish/container-images/pod-security-webhook-{psaimageversion}.tgz"
    checksum_cmd = f"cd /opt/gateway/images/ && sha256sum pod-security-webhook-{psaimageversion}.tgz | cut -d' ' -f1"
    status2 = execute_curl_with_retry(curl_cmd, checksum_cmd, psacontimg, pwd_encrypted_curl_cmd)

    if status1 and status2:
        return True

    print("Failed to download pod security webhook docker image and files")
    logging.error("Failed to download pod security webhook docker image and files")
    return False

def copy_k3s_images_and_manifests():
    print("INFO: Copying the images and manifests........")
    cmd = '''
            cp /opt/gateway/automation/bin/k3s /usr/local/bin/k3s
            chmod +x /usr/local/bin/k3s
            mkdir -p /var/lib/rancher/k3s/agent/images/ 
            rm -rf /opt/gateway/images/*kubevirt-cdi*
            rm -rf /opt/gateway/images/*kubevirt-virt*
            rm -rf /opt/gateway/images/*calico*
            #cp -rpf /opt/gateway/automation/k3s/images/* /var/lib/rancher/k3s/agent/images/
            cp -rpf /opt/gateway/automation/k3s/images/*kube-vip* /var/lib/rancher/k3s/agent/images/
            cp -rpf /opt/gateway/automation/k3s/images/*k3s-airgap* /var/lib/rancher/k3s/agent/images/
            cp -rpf /opt/gateway/images/pod-security-webhook-*.tgz /var/lib/rancher/k3s/agent/images/
            tar -zxvf /opt/gateway/podsecuritywebhook/pod-security-webhook.tgz -C /opt/gateway/automation
            #rm /opt/gateway/automation/pod-security-webhook/exemptions.yaml /opt/gateway/automation/pod-security-webhook/exemptions_edgeDC.yaml
            #mv /opt/gateway/automation/pod-security-webhook/exemptions_edge.yaml /opt/gateway/automation/pod-security-webhook/exemptions.yaml
            mkdir -p /var/lib/kubelet/plugins_registry/
            cp -rpf /opt/gateway/automation/k3s/manifests/system-upgrade-controller.yaml /var/lib/rancher/k3s/server/manifests/ 2>/dev/null
            rm -rf /var/lib/rancher/k3s/server/manifests/cdi*
            rm -rf /var/lib/rancher/k3s/server/manifests/kubevirt*
            rm -rf /var/lib/rancher/k3s/server/manifests/tigera-operator.yaml
            imagelist=("pod-security-webhook" "docker.io-goharbor" "quay.io-metallb" "ghcr.io-kube-vip" "k8s.gcr.io-external-dns" "registry.k8s.io-ingress")
            for image in ${imagelist[@]}; do
                cp -rpf /opt/gateway/images/$image* /var/lib/rancher/k3s/agent/images/ > /dev/null
            done
            gunzip -f /var/lib/rancher/k3s/agent/images/*.tgz > /dev/null
            echo "INFO: Copied the images and manifests."
          '''
    flag, out, err = commonutil.execute_command(cmd)
    return True

def install_k3s():
    print("INFO: Installing K3S........")
    logging.info("INFO: Installing K3S........")
    cmd = '''
            cat /opt/gateway/automation/scripts/k3s-install.sh | INSTALL_K3S_SKIP_DOWNLOAD=true INSTALL_K3S_SELINUX_WARN=true sh -s - --disable=traefik --disable servicelb --flannel-cni-conf "/opt/gateway/automation/cni/10-flannel.conlist" --kube-apiserver-arg="admission-control-config-file=/opt/gateway/automation/pod-security-webhook/psa_audit_config/admission_controller_edge.yaml" --kube-apiserver-arg="--audit-log-path=/var/lib/rancher/k3s/server/logs/audit.log" --kube-apiserver-arg="--audit-policy-file=/opt/gateway/automation/pod-security-webhook/psa_audit_config/audit.yaml" --default-local-storage-path=/data/storageClass > /dev/null 2> /dev/null
            sleep 150
            echo "INFO: Installed K3S"
          '''
    flag, out, err = commonutil.execute_command(cmd)
    return True

def get_node_status():
    timeout = time.time() + 60*15   # 15 minutes max wait time
    ready = False
    while True:
        cmd = "kubectl get nodes | grep Ready"
        flag, out, err = commonutil.execute_command(cmd)
        if out is None:
            print("ERROR: Something went wrong, command might have timed out, please check manually")
            logging.error("ERROR: Something went wrong, command might have timed out, please check manually")
            return None
        if out:
            if "NotReady" in out:
                print("WARN: Node is not Ready yet, will check again")
            else:
                ready = True
                break
        if time.time() > timeout:
            break
        time.sleep(5)
        print("--- Remaining time in %.2f seconds ---" % (time.time() - timeout))
        logging.info("--- Remaining time in %.2f seconds ---" % (time.time() - timeout))

    if ready:
        print("INFO: Node is Ready")
        logging.info("INFO: Node is Ready")
        return True
    else:
        print("ERROR: Node is not Ready")
        logging.error("ERROR: Node is not Ready")
        if err:
            print(err)
        return None

def main():
    parser = argparse.ArgumentParser(description=PURPOSE, formatter_class=RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-csversion", dest="csversion", help="Input container service version: -csversion csversion", type=str, default="none")
    parser.add_argument("-psaversion", dest="psaversion", help="Input pod security webhook version: -psaversion psaversion", type=str, default="none")
    parser.add_argument("-psaimageversion", dest="psaimageversion", help="Input pod security webhook docker image version: -psaimageversion psaimageversion", type=str, default="none")
    parser.add_argument("-jfroguser", dest="jfroguser", help="Input jfroguser: -jfroguser jfroguser", type=str, default="none")
    parser.add_argument("-jfrogpassword", dest="jfrogpassword", help="Input jfrogpassword: -jfrogpassword jfrogpassword", type=str, default="none")
    parser.add_argument("-psacontimg", dest="psacontimg", help="Enter the sha256checksum of psa container image. Input psacontimg: -psacontimg 1cef343a059e2e87b4321c2bb1d5c434988c4903e9835f6c0e7f9a3de76e37e8", type=str, default="none")
    parser.add_argument("-psatgzchecksum", dest="psatgzchecksum", help="Enter the sha256checksum of psa tgz. Input psatgzchecksum: -psatgzchecksum 6a192b401e40b74eb1bb44a6e04f7ddfcf678201950d9859a89bcd0065bd0fdc", type=str, default="none")
    parser.add_argument("-rpmchecksum", dest="rpmchecksum", help="Enter the sha256checksum of lhcp container services rpm. Input rpmchecksum: -rpmchecksum e031e59769c40df31c69c40372cc66e8938cdd83e1dc05cabc0087190daf461d", type=str, default="none")
    args = parser.parse_args()
    csversion = args.csversion
    psaversion = args.psaversion
    psaimageversion = args.psaimageversion
    jfroguser = args.jfroguser
    jfrogpassword = args.jfrogpassword
    psacontimg = args.psacontimg
    psatgzchecksum = args.psatgzchecksum
    rpmchecksum = args.rpmchecksum
    
    result_fp = "/var/log/gateway"
    commonutil.log_path_check(result_fp)
    fname = "result_k3s.log"
    log_file_path = os.path.join(result_fp, fname)
    logging.basicConfig(level=logging.DEBUG, filename=log_file_path, filemode="a+", format="%(asctime)-15s %(levelname)-8s %(message)s")   
    output = install_containerservice_rpm(csversion, jfroguser, jfrogpassword, rpmchecksum)
 
    if not output:
        print("ERROR: Failed to copy and install container services....")        
        logging.error("ERROR: Failed to copy and install container services....")
        sys.exit(1)        

    output1 = download_psa_files(psaversion, psaimageversion, jfroguser, jfrogpassword, psacontimg, psatgzchecksum)
    if not output1:
        print("ERROR: Failed to download pod security webhook files....")
        logging.error("ERROR: Failed to download pod security webhook files....")
        sys.exit(1)
    copy_k3s_images_and_manifests()
    install_k3s()
    output = get_node_status()

    if output:
        ExitCode = 0
        print("K3S deployed successfully")
    else:
        ExitCode = 1
        print("Failed to Deploy K3S")
    
    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
