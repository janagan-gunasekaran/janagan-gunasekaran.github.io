import argparse
import subprocess
from argparse import RawTextHelpFormatter
import os
import sys
from lib import commonutil
import logging

PURPOSE = "Deploy Pod Security Webhook"

def deploy_webhook():
    cmd = "kubectl apply -f /tmp/pod-security-webhook.yaml"
    status, output, error = commonutil.execute_command(cmd)
    cmd = "kubectl rollout status deployment.apps/pod-security-webhook -n pod-security-webhook --timeout=120s"
    flag, out, err = commonutil.execute_command(cmd)
    if flag == 0 and "successfully rolled out" in out:
        print("INFO: pod-security-webhook Deployment is successfully rolled out, proceeding")
        logging.info("INFO: pod-security-webhook Deployment is successfully rolled out, proceeding")
    else:
        print("ERROR: pod-security-webhook Deployment is NOT successfully rolled out, exiting")
        logging.info("ERROR: pod-security-webhook Deployment is NOT successfully rolled out, exiting")
        print("ERROR: cleanup and restart the task after understanding the failure")
        logging.info("ERROR: cleanup and restart the task after understanding the failure")
        return None
    
    # compare all CA certs are matching.
    cmd = r"kubectl get secret -n pod-security-webhook pod-security-webhook-tls -o jsonpath={.data.ca\\.crt} | base64 -d | xargs"
    status, output1, error = commonutil.execute_command(cmd)
    cmd = r"kubectl get validatingwebhookconfiguration pod-security-webhook.kubernetes.io -o jsonpath={.webhooks[0].clientConfig.caBundle} | base64 -d | xargs"
    status, output2, error = commonutil.execute_command(cmd)
    cmd = r"kubectl get validatingwebhookconfiguration pod-security-webhook.kubernetes.io -o jsonpath={.webhooks[1].clientConfig.caBundle} | base64 -d | xargs"
    status, output3, error = commonutil.execute_command(cmd)
    cmd = "cat /etc/ssl/certs/CA.pem | xargs"
    status, output4, error = commonutil.execute_command(cmd)
    cmd = "cat /var/lib/rancher/k3s/server/tls/server-ca.crt | xargs"
    status, output5, error = commonutil.execute_command(cmd)
    output_list = (output1,output2,output3,output4,output5)
    if len(set(output_list)) != 1 :
        print("Not all CA certificates are matching, exiting")
        print("cleanup and restart the task after understanding the failure")
        return None 
    return True

def main():    
    
    result_fp = "/var/log/gateway"
    commonutil.log_path_check(result_fp)
    fname = "result_podsecuritywebhook.log"
    log_file_path = os.path.join(result_fp, fname)
    logging.basicConfig(level=logging.DEBUG, filename=log_file_path, filemode="a+", format="%(asctime)-15s %(levelname)-8s %(message)s")
   

    print("SSH connection created for edge vm, Pass")
    logging.info("SSH connection created for edge vm, Pass")
    print("Deploy Pod Security Webhook started")
    logging.info("Deploy Pod Security Webhook started")
    cmd = "cd /opt/gateway/automation/pod-security-webhook/ && make clean && make build_save_copy FILE_NAME=exemptions_edge.yaml"
    status, output, error = commonutil.execute_command(cmd)
    if output:
        print((output.encode("utf-8")).decode("utf-8"))
        logging.info((output.encode("utf-8")).decode("utf-8"))
    result = deploy_webhook()
    if result:
        ExitCode = 0
        print("Pod Security Webhook deployed successfully")
        logging.info("Pod Security Webhook deployed successfully")
    else:
        ExitCode = 1
        print("Failed to Deploy od Security Webhook")
        logging.error("Failed to Deploy od Security Webhook")

    if ExitCode >= 1:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
