import json
import argparse
import os
import sys
import logging
from pathlib import Path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mod_cloudinit"))

if __name__ == "__main__":
    script_path = os.path.dirname(os.path.abspath(__file__))
    print(f'Script path: {script_path}')
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', action="store", dest="json", help="json file from server", type=str, required=True)
    parser.add_argument("-t", action="store", dest="template", help="Input template file", type=str, required=True)
    parser.add_argument("-o", action="store", dest="output", help="Output file", type=str, required=True)
    
    parser.parse_args()
    log_folder = Path(parser.parse_args().output).parent
    log_path = os.path.join(str(log_folder), 'execution.log')
    logging.basicConfig(
        filename=r'{}'.format(log_path),
        format="%(levelname)s: %(asctime)s %(message)s",
        filemode='w',
        level=logging.INFO)
    logging.info("\tScript path:{}".format(script_path))
    logging.info("\t{}".format(sys.path))
    try:
        sys.path.append(script_path)
        from mod_cloudinit.cloud_init import RenderTemplates

    except ImportError:
        raise ImportError

    value_json = parser.parse_args().json
    template_dir = parser.parse_args().template
    output_dir = parser.parse_args().output

    obj_render = RenderTemplates(value_json, template_dir, output_dir)

    if obj_render.check_inputs:
        dict_templates = obj_render.get_template_filepath()
        if len(dict_templates):
            for name, template_dir in dict_templates.items():
                output_filepath = os.path.join(obj_render.output_dir, name)
                obj_render.render_file(template_dir, output_filepath)
        else:
            print("\tNo template files found at provided template location!")
        print("Code executed")
