import paramiko

def establish_ssh_connection(host_ip, username, password):
    "Login to the remote server"
    result_flag = "Pass"
    try:
        print("Establishing SSH connection to", host_ip, "...")
        client = paramiko.SSHClient()
        # Set the host key policy to automatically add unknown host keys
        policy = paramiko.AutoAddPolicy()
        client.set_missing_host_key_policy(policy)
        client.connect(hostname=host_ip, username=username, password=password, timeout=20, allow_agent=False,look_for_keys=False)
        print(host_ip, " - Connected to the server")
    except Exception as e:
        print(f"Exception in connecting to the server {host_ip}. Exception: {e}")
        result_flag = "Fail"
    else:
        result_flag = "Pass"
    return client, result_flag

def execute_command(client, command, passwords=None, timeout=600, exitCode=False, printCmd = True):
    """Execute a command on the remote host
    Arguments: 
        password: if password argument is passed, hide it while logging
    """
    out = None
    err = None
    result_flag = "Pass"
    cmdexitcode = 1
    command_to_be_logged = command
    # in the command, hide the password so that it will not be logged
    if passwords is not None:
        for password in passwords:
            command_to_be_logged = command_to_be_logged.replace(password, "XXXX")
    try:
        if printCmd == True:
            print("Executing command : ", (command_to_be_logged))
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        out = stdout.read().decode('UTF-8').strip("\n")
        err = stderr.read().decode('UTF-8').strip("\n")
        if exitCode:
            cmdexitcode = stdout.channel.recv_exit_status()
        if cmdexitcode != 0 and exitCode:
            print(f"Problem occurred while running command: {command_to_be_logged} : {err}")
            result_flag = "Fail"
        elif err:
            print(f"Problem occurred while running command {command_to_be_logged} : {err}")
            result_flag = "Fail"
        print("Executed command %s and output is %s,result_flag is %s"%(command_to_be_logged, out, result_flag))
    except Exception as e:
        print(f"Failed to execute the command - {command_to_be_logged} . Exception : {e}")
        result_flag = "Fail"
    return result_flag, out, err
    
