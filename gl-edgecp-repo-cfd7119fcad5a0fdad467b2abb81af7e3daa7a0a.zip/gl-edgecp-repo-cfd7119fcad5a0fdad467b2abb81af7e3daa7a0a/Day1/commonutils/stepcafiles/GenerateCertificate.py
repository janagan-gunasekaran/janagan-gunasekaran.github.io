import argparse
import sys
import os
import logging
import json
import time
import base64
from lib import commonutil

application_name = "GenerateCertificate"
result_fp = "/var/log/gateway/"
config_file_path = "/opt/gateway/conf/config.json"
cert_fp = "/opt/gateway/conf/certvm.json"
deployer_fp = "/opt/gateway/scripts/deployer.json"
install_csfp = "/opt/gateway/scripts/cert-svc-installer-"

def cleanup_cert_data():
    flag = True
    cmd01 = "rm -f /opt/gateway/scripts/deployer.json"
    cmd02 = "rm -f /opt/gateway/scripts/cert-svc-installer-*"

    status01, out01, error01 = commonutil.execute_command(cmd01)
    status02, out02, error02 = commonutil.execute_command(cmd02)

    if status01 == 0:
        print("Existing deployer.json file deleted successfully.")
        logging.info("Existing deployer.json file deleted successfully.")
    else:
        print("Failed to delete existing deployer.json file.", out01, error01)
        logging.info(f"Failed to delete existing deployer.json file. Output: {out01}, Error: {error01}")
        flag = flag and False

    if status02 == 0:
        print("Existing cert-svc-installer file deleted successfully.")
        logging.info("Existing cert-svc-installer file deleted successfully.")
    else:
        print("Failed to delete existing cert-svc-installer file.", out02, error02)
        logging.info(f"Failed to delete existing cert-svc-installer file. Output: {out02}, Error: {error02}")
        flag = flag and False
    return flag

def cd_and_download_from_jfrog(username, password, url, **kwargs):
    print("downloading %s from Jfrog" % url)
    version = kwargs.get('version', "")
    cmd = "cd /opt/gateway/scripts && wget --user %s --password '%s' %s%s" % (username, password, url, version)
    status, out, error = commonutil.execute_command(cmd)
    return status, out, error


def download_script_conf(cert_svc_data):
    status = False
    global install_csfp
    if cleanup_cert_data():
        for i in range(0,3):
            status01, out01, error01 = cd_and_download_from_jfrog(cert_svc_data["jfrog_username"], cert_svc_data["jfrog_password"],cert_svc_data["jfrog_deployer_json_url"])
            if status01 == 0 and check_file(deployer_fp):
                break
            if status01 != 0 and i == 2:
                print(f"Failed to download deployer.json in /opt/gateway/scripts/", error01)
                logging.info(f"Failed to download deployer.json in /opt/gateway/scripts/ Output: {out01}, Error: {error01}")
                return (f"Failed to download deployer.json in /opt/gateway/scripts/", status)
            print("Retrying ...")
            time.sleep(10)
        print("Deployer.json is downloaded and available")
        logging.info("Deployer.json is downloaded and available")
        cmd02 = "cat /opt/gateway/scripts/deployer.json | grep version | awk -F '\"' '{print $4}'"
        status02, out02, error02 = commonutil.execute_command(cmd02)
        if status02 == 0:
            version = out02.strip()
            for i in range(0,3):
                status03, out03, error03 = cd_and_download_from_jfrog(cert_svc_data["jfrog_username"], cert_svc_data["jfrog_password"], cert_svc_data["jfrog_install_script_url"], version=version)
                if status03 == 0 and check_file(f"{install_csfp}{version}"):
                    break
                if status03 != 0 and i == 2:
                    print(f"Failed to download cert-svc-installer-{version} in /opt/gateway/scripts/", out03, error03)
                    logging.info(f"Failed to download cert-svc-installer-{version} in /opt/gateway/scripts/ Output: {out03} Error: {error03}")
                    return (f"Failed to download cert-svc-installer-{version} in /opt/gateway/scripts/", status)
                print("Retrying ...")
                time.sleep(10)
            install_csfp += version
            print(f"cert-svc-installer-{version} is downloaded and available")
            logging.info(f"cert-svc-installer-{version} is downloaded and available")
            status = True                
        else:
            print("Failed to fetch verion from deployer.json", out02, error02)
            logging.info(f"Failed to fetch verion from deployer.json Output: {out02}, Error: {error02}")
            return ("Failed to fetch verion from deployer.json", status)
    else:
        print("Unable to delete the existing downloaded file")
        logging.log("Unable to delete the existing downloaded file")
        return ("Unable to delete the existing downloaded file", status)
    
    logging.info("Script and config file downloaded successfully")
    return("Script and config file downloaded successfully",status)

def deploy_cert_service():
    flag = False
    chmod_cmd = f"chmod +x {install_csfp}"
    sh_cmd = f"{install_csfp} --json {deployer_fp}"
    status, cmd_out, cmd_err = commonutil.execute_command(chmod_cmd)
    if status == 0:
        status, cmd_out, cmd_err = commonutil.execute_command(sh_cmd)
        if status == 0:
            flag = True
    else:
        logging.info("Failed to run command '{}'".format(chmod_cmd))
        return("Failed to run command '{}'".format(chmod_cmd),flag)
    intermediate_ca="/opt/glcg/certificates/certs/intermediate_ca.crt"
    intermediate_ca_key="/opt/glcg/certificates/secrets/intermediate_ca_key"
    if check_file(intermediate_ca) and check_file(intermediate_ca_key):
        logging.info("Certificate service deployed succesfully")
        return("Certificate service deployed succesfully",flag)
    else:
        logging.info("{0} and {1} certificate files doesnot exists.".format(intermediate_ca,intermediate_ca_key))
        return("{0} and {1} certificate files doesnot exists.".format(intermediate_ca,intermediate_ca_key),flag)

def check_file(path):
    try:
        file = os.path.split(path)[-1]
        base_path = os.path.split(path)[0]
        data = os.listdir(base_path)
        if file in data:
            return("Done",True)
        else:
            return("File not found in directory", False)
    except Exception as e:
        return("Exception: " + str(e), False)

def update_deployer_jsonfile(cert_svc_data, dnsserver, dnsdomain, coreserver, corefingerprint, pdnsapikey):
    status = False
    try:
        logging.info("Updating deployer json file")
        json_file = open(deployer_fp, "r")
        data = json.load(json_file)
        json_file.close()
        data["artifactory"]["username"] = cert_svc_data["jfrog_username"]
        data["artifactory"]["password"] = cert_svc_data["jfrog_password"]
        data["certArtifacts"]["nfsIp"] = ""
        data["dns"]["server"] = dnsserver 
        data["dns"]["domain"] = dnsdomain 
        data["dns"]["pdnstoken"] = pdnsapikey
        data["core"]["server"] = coreserver 
        data["core"]["fingerprint"] = corefingerprint 
        json_file = open(deployer_fp, "w+")
        json_file.write(json.dumps(data))
        json_file.close()
        status = True
    except Exception as e:
        logging.info("Error in update_deployer_jsonfile(). Error: %s" % e)
        return("Error in update_deployer_jsonfile(). Error: %s" % e,status)
    logging.info("Deployer json file updated succesfully")
    return("Deployer json file updated succesfully",status)

def get_cert_metadata(tags):
    global certsvc_meta_data
    status = False
    try:
        logging.info("Getting certificate metadata")
        certsvc_meta_data = {}
        with open(cert_fp, 'r') as file:
            certsdata = json.load(file)
            jfrog_username = decode_string(certsdata["artifactory"]["jfrog_username"])
            jfrog_password = decode_string(certsdata["artifactory"]["jfrog_password"])
            certsvc_meta_data["jfrog_username"] = jfrog_username
            certsvc_meta_data["jfrog_password"] = jfrog_password
            certsvc_meta_data["jfrog_artifactory_url"] = certsdata["artifactory"]["url"]
            certsvc_meta_data["jfrog_deployer_json_url"] = certsdata["artifactory"]["deployer_json"]
            certsvc_meta_data["jfrog_install_script_url"] = certsdata["artifactory"]["certsvc_script"]
            certsvc_meta_data["primaryDnsIpAddress"] = tags["ipaddress"]
            certsvc_meta_data["domainSearchName"] = tags["domainName"]
            status = True
        logging.info("Processed certificate metadata succesfully")
    except Exception as e:
        logging.info("Error in get_cert_metadata(). Error: %s" % e)
    return(status,certsvc_meta_data)

def decode_string(encoded_string):
    base64_bytes = encoded_string.encode("ascii")
    string_bytes = base64.b64decode(base64_bytes)
    decoded_string = string_bytes.decode("ascii")
    return(decoded_string)

def main():
    parser = argparse.ArgumentParser(description=application_name, formatter_class=argparse.RawTextHelpFormatter, epilog=" ")
    parser.add_argument("-dnsserver", dest="dnsserver", help="Input dns server ip", type=str, required=True)
    parser.add_argument("-dnsdomain", dest="dnsdomain", help="Input dns domain name", type=str, required=True)
    parser.add_argument("-coreserver", dest="coreserver", help="Input core server", type=str, required=True)
    parser.add_argument("-corefingerprint", dest="corefingerprint", help="Input core fingerprint", type=str, required=True)
    parser.add_argument("-pdnsapikey", dest="pdnsapikey", help="Input pdns api key", type=str, required=True)

    args = parser.parse_args()
    dnsserver = args.dnsserver
    dnsdomain = args.dnsdomain
    coreserver = args.coreserver
    corefingerprint = args.corefingerprint
    pdnsapikey = args.pdnsapikey

    global result_fp, config_file_path
    commonutil.log_path_check(result_fp)
    fname = "result_"+application_name+".log"
    fpath = os.path.join(result_fp, fname)
    task_name = "{}".format(application_name)
    exit_code = 0
    logging.basicConfig(level=logging.DEBUG, filename=fpath, filemode="a+", format="%(asctime)-15s %(levelname)-8s %(message)s")
    logging.info("Generate Certificate in Lockmaker started")
    tags, status = commonutil.get_tags(config_file_path)
    out = ''
    status,cert_svc_data = get_cert_metadata(tags)
    if status:
        out,status = download_script_conf(cert_svc_data)
    else:
        logging.info("Failed to download script: {}".format(out))
    if status:
        out,status = update_deployer_jsonfile(cert_svc_data=cert_svc_data, dnsserver=dnsserver, dnsdomain=dnsdomain, coreserver=coreserver, corefingerprint=corefingerprint, pdnsapikey=pdnsapikey)
    else:
        logging.info("Failed to update deployer json file: {}".format(out))
    if status:
        out,status = deploy_cert_service()
    exit_code = status
    if not exit_code:
        result_str = "%s : Failed" % (task_name)
    else:
        result_str = "%s : Passed" % (task_name)
    logging.info(result_str)
    print(result_str)
    if not exit_code:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()