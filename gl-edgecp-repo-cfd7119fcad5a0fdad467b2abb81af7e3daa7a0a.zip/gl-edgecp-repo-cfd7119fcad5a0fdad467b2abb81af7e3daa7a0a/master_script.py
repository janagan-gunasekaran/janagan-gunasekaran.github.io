#Run createconfigdata.py querying the GTS API/Config DB API ( requests module )
#Run createcloudiso.py ( mkisofs , pyyaml )
#Run movecloudisotovsandatastore.py
#Run mountcloudisotocddrive.ps1 
#Run poweronedgevm.ps1
#Run deployservices ( K3S, Step-CA, Container-Services - ArgoCD, Harbor, Pulp, Metallb, ExternalDNS, local-path StorageClass )
#!/usr/bin/python
#!/usr/bin/python
import os
import sys
import json
import argparse
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("edgeid")
parser.add_argument("jsonFile")
#parser.add_argument('edge_id')
#parser.add_argument('ztp_json')
args = parser.parse_args()

edgeid=args.edgeid
file_json=args.jsonFile
#ztp_json="/opt/config.json"
#Jsons will be available in artIfacts folder outside scripts directory
ztp_json=os.environ['ARTIFACTS_HOME']+"/"+file_json

try:
    retcode = subprocess.run(['python', os.environ['CP_HOME']+'/Day1/day1.py' ,ztp_json,edgeid])
    if retcode.returncode != 0:
        sys.exit(retcode.returncode)
    else:
        sys.exit(0)
except OSError as e:
    print( e, file=sys.stderr)
    sys.exit(e)

#script exits with exit code 0 if successful else non zero